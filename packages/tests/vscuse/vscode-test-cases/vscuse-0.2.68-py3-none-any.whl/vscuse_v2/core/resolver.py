#!/usr/bin/env python3
"""
Environment Variable Resolver

Handles resolution, validation, and masking of environment variables in executable plans.
Supports ${{type:name:default}} syntax with comprehensive privacy protection.

Supported variable types:
- ${{env:VAR_NAME:default_value}} - Environment variable with optional default
- ${{secret:VAR_NAME}} - Secure environment variable (always masked)
- ${{mfa_code:SECRET_VAR_NAME}} - TOTP/MFA code generator from secret (temporary, not masked)
- ${{var:variable_name:value}} - Custom variable with direct value or template
- ${{fact:fact_name}} - Runtime fact stored by a previous step (no default allowed)

Runtime shared variables:
- Same variable name generates same value across all steps in an execution
- Example: ${{var:app_name:app_######}} in step 1 and step 5 will have the same value

Fact variables:
- Facts are stored by code agent using store_fact:name tag
- Referenced with ${{fact:fact_name}} syntax
- Cannot have default values (must be stored by prior step)
- Example: ${{fact:npm_version}} retrieves the npm_version fact

Variable template examples:
- ${{var:app_name:app_######}} -> app_aB3x9Z (shared across all steps)
- ${{var:user_id:user_###}} -> user_aB3 (shared across all steps)
- ${{var:session:test_###_end}} -> test_aB3_end (shared across all steps)
- ${{var:direct_value:hello}} -> hello (direct value, shared across all steps)
"""

import os
import random
import re
import string
from typing import Dict, Tuple

from vscuse_v2.utils.logger import setup_logger

from .fact_store import FactStore
from .schema import ExecutablePlan, Step

logger = setup_logger(__name__)


class RuntimeContext:
    """Global runtime context singleton for variable caching."""

    _instance = None
    _variables: Dict[str, str] = {}

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    def get_variables(self) -> Dict[str, str]:
        """Get the global variables."""
        return self._variables

    def reset_variables(self):
        """Reset the global variables."""
        self._variables.clear()
        logger.debug("Runtime context variables reset")

    def get_cached_variables(self) -> Dict[str, str]:
        """Get a copy of cached variables for debugging purposes."""
        return self._variables.copy()


class Resolver:
    """Handles environment variable resolution and masking for plans and steps."""

    def __init__(self,
                 pattern: str = r'\$\{\{(env|secret|mfa_code|var|fact):([A-Za-z_][A-Za-z0-9_]*):?([^}]*)\}\}'):
        """
        Initialize the environment variable resolver.

        Args:
            pattern: Regex pattern for variables (default: ${{type:name:default}})
        """
        self.var_pattern = pattern
        self.runtime_context = RuntimeContext()
        self.fact_store = FactStore()

    @property
    def _runtime_variables(self) -> Dict[str, str]:
        """Get the global runtime variables."""
        return self.runtime_context.get_variables()

    def reset_runtime_variables(self):
        """Reset the global runtime variables. Call this when starting a new execution."""
        self.runtime_context.reset_variables()

    def get_runtime_variables(self) -> Dict[str, str]:
        """Get a copy of the current runtime variables for debugging purposes."""
        return self.runtime_context.get_cached_variables()

    def _parse_variable_syntax(self, var_match: tuple) -> Tuple[str, str, str]:
        """
        Parse the new variable syntax to extract type, name, and default.

        Args:
            var_match: Tuple from regex match (type, name, default)

        Returns:
            Tuple of (var_type, var_name, default_value)
        """
        var_type, var_name, default_part = var_match
        default_value = default_part if default_part else ""
        return var_type, var_name, default_value

    def _generate_totp_code(self, secret: str, time_step: int = 30, digits: int = 6) -> str:
        """
        Generate a TOTP code from a secret key.

        Args:
            secret: The base32-encoded secret key
            time_step: Time step in seconds (default: 30)
            digits: Number of digits in the code (default: 6)

        Returns:
            The TOTP code as a string
        """
        import base64
        import hmac
        import struct
        import time

        # Normalize the secret (remove spaces and convert to uppercase)
        secret = secret.replace(" ", "").upper()

        # Decode the base32 secret
        try:
            key = base64.b32decode(secret, casefold=True)
        except Exception as e:
            raise ValueError(f"Invalid TOTP secret key: {e}")

        # Get the current time counter
        time_counter = int(time.time() / time_step)

        # Convert counter to bytes (big-endian)
        time_bytes = struct.pack(">Q", time_counter)

        # Generate HMAC-SHA1 hash
        hmac_hash = hmac.new(key, time_bytes, "sha1").digest()

        # Dynamic truncation
        offset = hmac_hash[-1] & 0x0F
        truncated_hash = struct.unpack(">I", hmac_hash[offset:offset + 4])[0]
        truncated_hash &= 0x7FFFFFFF

        # Generate the code
        code = truncated_hash % (10 ** digits)

        # Return as zero-padded string
        return str(code).zfill(digits)

    def _process_default_value(self, template: str) -> str:
        """
        Process default value, generating random values for templates with # patterns.

        Args:
            template: Template string with # patterns for random character replacement,
                     or direct value for var type

        Returns:
            Processed value

        Examples:
            _process_default_value('app_######') -> 'app_aB3x9Z' (random generation)
            _process_default_value('user_###_test') -> 'user_aB3_test' (random generation)
            _process_default_value('########') -> 'aB3x9ZmK' (random generation)
            _process_default_value('') -> 'aB3x9ZmK' (default 8 chars)
            _process_default_value('direct_value') -> 'direct_value' (no # chars, return as-is)
        """
        # Create character set excluding OCR-confusing characters
        # Excluded: 0/O/o (zero/O), 1/I/i/l/L (one/I/l), 2/Z (two/Z), 5/S (five/S), 8/B (eight/B)
        # These characters are visually similar and hard for AI OCR to distinguish
        all_chars = string.ascii_letters + string.digits
        ocr_safe_chars = ''.join(c for c in all_chars if c not in '0Oo1IiLl2Zz5Ss8B')

        # If no template provided, generate default 8-character alphanumeric string
        if not template:
            return ''.join(random.choices(ocr_safe_chars, k=8))

        # If template contains # patterns, replace with random characters
        if '#' in template:
            result = template

            # Replace each # with a random alphanumeric character
            for _ in range(template.count('#')):
                random_char = random.choice(ocr_safe_chars)
                result = result.replace('#', random_char, 1)

            return result

        # If no # patterns, return template as direct value
        return template

    def _resolve_variable_value(self, var_type: str, var_name: str, default_value: str) -> Tuple[str, bool]:
        """
        Resolve a variable value based on its type.

        Validation logic:
        1. env: must have value from os.getenv or default value
        2. secret: must have value from os.getenv, must not have default value
        3. mfa_code: must have secret value from os.getenv, generates TOTP code
        4. var: must have default value at first time use

        Args:
            var_type: Type of variable ('env', 'secret', 'var')
            var_name: Name of the variable
            default_value: Default value or additional parameter

        Returns:
            Tuple of (resolved_value, is_sensitive)
        """
        if var_type == 'env':
            env_value = os.getenv(var_name)

            if env_value is not None:
                # Environment variable is set, use it
                return env_value, False
            elif default_value:
                # Environment variable not set, but default provided
                return default_value, False
            else:
                # Environment variable not set and no default provided
                raise EnvironmentError(f"Environment variable '{var_name}' is not set and no default provided")

        elif var_type == 'secret':
            # Secrets must not have defaults (security requirement)
            if default_value:
                raise ValueError(f"Secret variable '{var_name}' cannot have a default value")

            env_value = os.getenv(var_name)
            if env_value is None:
                raise EnvironmentError(f"Secret environment variable '{var_name}' is not set")

            return env_value, True

        elif var_type == 'mfa_code':
            # MFA codes must not have defaults (security requirement)
            if default_value:
                raise ValueError(f"MFA code variable '{var_name}' cannot have a default value")

            secret_value = os.getenv(var_name)
            if secret_value is None:
                raise EnvironmentError(f"MFA secret environment variable '{var_name}' is not set")

            # Generate TOTP code from the secret
            try:
                totp_code = self._generate_totp_code(secret_value)
                logger.debug(f"Generated TOTP code for '{var_name}'")
                return totp_code, False  # Not sensitive - codes expire in 30 seconds
            except Exception as e:
                raise ValueError(f"Failed to generate TOTP code for '{var_name}': {e}")

        elif var_type == 'var':
            logger.debug(f"Variable '{var_name}' - variables contents: {self._runtime_variables}")

            # Check if we already have this variable value
            if var_name in self._runtime_variables:
                logger.debug(f"Reusing existing value for '{var_name}': '{self._runtime_variables[var_name]}'")
                return self._runtime_variables[var_name], False

            # Var variables must have a default value at first time use
            if not default_value:
                raise ValueError(f"Custom variable '{var_name}' must specify a value or template at first use")

            # Process the default value (handles both direct values and templates)
            processed_value = self._process_default_value(default_value)

            # Store it for future use in this execution
            self._runtime_variables[var_name] = processed_value
            logger.debug(f"Generated and stored value for '{var_name}': {processed_value}")

            return processed_value, False

        elif var_type == 'fact':
            # Fact variables retrieve values from the FactStore
            # Facts cannot have default values (must be stored by a prior step)
            if default_value:
                raise ValueError(f"Fact variable '{var_name}' cannot have a default value")

            fact_value = self.fact_store.get_fact(var_name)
            if fact_value is None:
                raise EnvironmentError(
                    f"Fact '{var_name}' is not available. "
                    f"Ensure a prior step with 'store_fact:{var_name}' tag has executed successfully."
                )

            logger.debug(f"Retrieved fact '{var_name}': {fact_value}")
            return fact_value, False  # Facts are not sensitive

        else:
            raise ValueError(f"Unknown variable type: {var_type}")

    def resolve_step_variables(self, step: Step) -> Step:
        """
        Resolve environment variables in step parameters and description.

        Resolves ${{type:name:default}} patterns with actual values.
        Supports: env (with defaults), secret (masked), mfa_code (TOTP, not masked),
                  var (custom values/templates), fact (runtime facts from prior steps).
        Adds metadata for later masking: _has_env_vars and _env_var_mappings.

        Args:
            step: Step to resolve environment variables for

        Returns:
            Step with resolved environment variables and masking metadata

        Raises:
            EnvironmentError: If required environment variables are missing
        """
        def resolve_vars_in_string(text: str) -> Tuple[str, Dict[str, str], bool]:
            """Resolve variables in a string using new syntax."""
            if not text:
                return text, {}, False

            mappings = {}
            has_sensitive = False

            def replace_match(match):
                nonlocal has_sensitive
                var_type, var_name, default_value = self._parse_variable_syntax(match.groups())
                resolved_value, is_sensitive = self._resolve_variable_value(var_type, var_name, default_value)

                if is_sensitive:
                    has_sensitive = True

                # Create placeholder for masking only for secret types
                if var_type == 'secret':
                    placeholder = f"${{{{{var_type}:{var_name}:{default_value}}}}}"
                    mappings[placeholder] = resolved_value

                return resolved_value

            resolved_text = re.sub(self.var_pattern, replace_match, text)
            return resolved_text, mappings, has_sensitive

        # Check if step contains variables
        has_env_vars = False
        env_var_mappings = {}
        contains_sensitive = False

        # Create a copy of the step to avoid modifying the original
        resolved_step = step.model_copy(deep=True)

        # Check and resolve variables in description
        if resolved_step.description:
            matches = re.findall(self.var_pattern, resolved_step.description)
            if matches:
                has_env_vars = True
                resolved_description, desc_mappings, desc_sensitive = resolve_vars_in_string(resolved_step.description)
                resolved_step.description = resolved_description
                env_var_mappings.update(desc_mappings)
                if desc_sensitive:
                    contains_sensitive = True
                logger.debug(f"Resolved {len(matches)} variables in description for step {step.step_id}")

        # Check and resolve variables in parameters
        if resolved_step.parameters:
            # Convert parameters to dict for processing
            params_dict = resolved_step.parameters.model_dump() if hasattr(resolved_step.parameters, 'model_dump') else resolved_step.parameters.__dict__

            resolved_params = {}
            for key, value in params_dict.items():
                if isinstance(value, str):
                    matches = re.findall(self.var_pattern, value)
                    if matches:
                        has_env_vars = True
                        resolved_value, param_mappings, param_sensitive = resolve_vars_in_string(value)
                        resolved_params[key] = resolved_value
                        env_var_mappings.update(param_mappings)
                        if param_sensitive:
                            contains_sensitive = True
                        logger.debug(f"Resolved {len(matches)} variables in parameter '{key}' for step {step.step_id}")
                    else:
                        resolved_params[key] = value
                else:
                    resolved_params[key] = value

            # Create new parameters object from resolved dict
            resolved_step.parameters = resolved_step.parameters.__class__(**resolved_params)

        # Flag the step if it contains variables
        if has_env_vars:
            # Add metadata to track sensitive data (using step attributes)
            resolved_step._has_env_vars = True
            resolved_step._env_var_mappings = env_var_mappings
            resolved_step._contains_sensitive = contains_sensitive

        return resolved_step

    def apply_sensitive_data_masking(self, result, step: Step):
        """
        Apply comprehensive sensitive data masking to a StepExecutionResult.

        Masks description, error, and result fields, and sets the sensitive data flag.

        Args:
            result: StepExecutionResult to mask
            step: Step with environment variable metadata

        Returns:
            StepExecutionResult: New result with sensitive data masked
        """
        if not hasattr(step, '_has_env_vars') or not step._has_env_vars:
            return result

        if not hasattr(step, '_env_var_mappings') or not step._env_var_mappings:
            return result

        # Create a copy of the result to avoid modifying the original
        masked_result = result.model_copy() if hasattr(result, 'model_copy') else result

        # Mask description field
        if hasattr(masked_result, 'description') and masked_result.description:
            masked_result.description = self._mask_sensitive_text(masked_result.description, step)

        # Mask error field
        if hasattr(masked_result, 'error') and masked_result.error:
            masked_result.error = self._mask_sensitive_text(masked_result.error, step)

        # Mask result field
        if hasattr(masked_result, 'result') and masked_result.result:
            masked_result.result = self._mask_sensitive_text(masked_result.result, step)

        # Flag that this step contains sensitive data
        if hasattr(masked_result, 'contains_sensitive_data'):
            masked_result.contains_sensitive_data = True

        return masked_result

    def _mask_sensitive_text(self, text: str, step: Step) -> str:
        """
        Mask sensitive values in any text field for steps with environment variables.

        Args:
            text: Text to mask
            step: Step with environment variable metadata

        Returns:
            Masked text with placeholders instead of actual values
        """
        if not hasattr(step, '_has_env_vars') or not step._has_env_vars:
            return text

        if not hasattr(step, '_env_var_mappings') or not step._env_var_mappings:
            return text

        if text is None:
            return text

        # Replace sensitive values with placeholders
        masked_text = text
        for env_placeholder, env_value in step._env_var_mappings.items():
            if env_value in masked_text:
                masked_text = masked_text.replace(env_value, env_placeholder)

        return masked_text

    def validate_variables(self, plan: ExecutablePlan) -> dict:
        """
        Validate variables in the plan according to these rules:
        1. env: must have value from os.getenv OR default value
        2. secret: must have value from os.getenv, must NOT have default value
        3. mfa_code: must have secret from os.getenv, must NOT have default value
        4. var: must have default value at first time use
        5. fact: must NOT have default value (runtime-only, existence checked during execution)

        Args:
            plan: ExecutablePlan to validate

        Returns:
            Dictionary with validation results:
            - If valid: {'valid': True}
            - If invalid: {
                'valid': False,
                'missing_env_vars': List[str],    # Missing environment variables (if any)
                'rule_violations': List[str]      # Validation rule violations (if any)
              }
        """
        # Collect all variables from the plan
        env_vars = set()           # All environment/secret variables
        secret_vars = set()        # Secret variables (subset of env_vars)
        var_vars = set()           # Custom variables
        env_with_defaults = set()  # Environment variables that have defaults
        validation_errors = []     # Rule violations

        # Track first occurrence of var variables to validate "first time use" rule
        var_first_occurrence = {}  # var_name -> (has_value, step_context)

        # Extract variables from all steps (in execution order, not array order)
        # Create a mapping of step_id -> step for efficient lookup
        steps_by_id = {step.step_id: step for step in plan.steps}

        # Process steps in execution order to properly validate variable first-use rules
        execution_order = plan.plan_metadata.execution_order if plan.plan_metadata.execution_order else [step.step_id for step in plan.steps]

        for step_index, step_id in enumerate(execution_order):
            if step_id not in steps_by_id:
                validation_errors.append(f"Step '{step_id}' in execution_order not found in steps")
                continue

            step = steps_by_id[step_id]
            step_texts = [step.description] if step.description else []

            # Add parameter values to check
            if step.parameters:
                params_dict = (step.parameters.model_dump() if hasattr(step.parameters, 'model_dump')
                              else step.parameters.__dict__)
                step_texts.extend([v for v in params_dict.values() if isinstance(v, str)])

            # Process all text fields in this step
            for text in step_texts:
                matches = re.findall(self.var_pattern, text)
                for match in matches:
                    var_type, var_name, default_value = self._parse_variable_syntax(match)

                    # Apply validation rules
                    if var_type == 'env':
                        env_vars.add(var_name)
                        if default_value:
                            env_with_defaults.add(var_name)

                    elif var_type == 'secret':
                        env_vars.add(var_name)
                        secret_vars.add(var_name)
                        # Rule: secrets cannot have defaults
                        if default_value:
                            validation_errors.append(f"Secret variable '{var_name}' cannot have a default value")

                    elif var_type == 'mfa_code':
                        env_vars.add(var_name)
                        secret_vars.add(var_name)  # Treated as secret for validation
                        # Rule: mfa_code cannot have defaults
                        if default_value:
                            validation_errors.append(f"MFA code variable '{var_name}' cannot have a default value")

                    elif var_type == 'var':
                        var_vars.add(var_name)
                        # Rule: var variables must have a value/template at FIRST time use
                        if var_name not in var_first_occurrence:
                            # This is the first occurrence
                            var_first_occurrence[var_name] = (bool(default_value), f"step {step.step_id}")
                            if not default_value:
                                validation_errors.append(f"Custom variable '{var_name}' must specify a value or template at first use (in {step.step_id})")
                        # Subsequent occurrences are allowed without values (will reuse cached value)

                    elif var_type == 'fact':
                        # Rule: fact variables cannot have defaults (they are runtime-only)
                        if default_value:
                            validation_errors.append(f"Fact variable '{var_name}' cannot have a default value")
                        # Note: We cannot validate fact existence at plan-load time
                        # since facts are created during execution by prior steps

                    else:
                        validation_errors.append(f"Unknown variable type '{var_type}' for variable '{var_name}'")

        # Check environment variable availability
        required_env_vars = env_vars - env_with_defaults  # Variables that MUST be set in environment
        missing_vars = [var for var in required_env_vars if os.getenv(var) is None]

        # Determine overall validation result
        is_valid = len(missing_vars) == 0 and len(validation_errors) == 0

        if is_valid:
            return {'valid': True}
        else:
            result = {'valid': False}
            if missing_vars:
                result['missing_env_vars'] = sorted(missing_vars)
            if validation_errors:
                result['rule_violations'] = validation_errors
            return result
