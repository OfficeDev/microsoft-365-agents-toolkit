#!/usr/bin/env python3
"""
Natural Language Plan Parser

Simple parser for extracting agent directives from step descriptions.
Only supports @agent patterns as that's the only functionality currently used.
"""

import re
from typing import Optional, Tuple

from .schema import Step


class Parser:
    """Simple parser for agent directives in step descriptions."""

    # Define parsing patterns as class constants for flexibility and future extension
    PATTERNS = {
        'agent_directive': re.compile(r'^@(\w+)\s+(.+)$', re.MULTILINE | re.DOTALL)
    }

    @staticmethod
    def parse_step(step: Step) -> Optional[Tuple[str, str]]:
        """Parse agent name and task from step description if it contains @agent_name pattern.

        Args:
            step: Step object containing description to parse

        Returns:
            Tuple of (agent_name, task) if found, None otherwise
        """
        if not step.description:
            return None

        # Use the agent directive pattern
        agent_match = Parser.PATTERNS['agent_directive'].match(step.description)
        if agent_match:
            agent_name = agent_match.group(1)
            task = agent_match.group(2)
            return (agent_name, task)

        return None
