#!/usr/bin/env python3
"""
Step Description Enhancement API using OpenAI Agents SDK
"""

import asyncio
import base64
import io
import tempfile
import time
from typing import Any, Dict, List, Optional

from agents import Agent, OpenAIChatCompletionsModel, Runner, set_tracing_disabled
from openai import AsyncAzureOpenAI
from PIL import Image, ImageDraw

from vscuse_v2.config import get_azure_openai_config
from vscuse_v2.core.schema import Step
from vscuse_v2.utils import AzureOpenAIClientFactory
from vscuse_v2.utils.logger import setup_logger

logger = setup_logger(__name__)

class AnalysisPromptTemplate:
    """Template for generating step analysis prompts."""

    AGENT_INSTRUCTIONS = """
You are an automation expert. Analyze screenshots and step parameters to generate clear, specific descriptions of UI interactions. Keep descriptions concise and actionable.
"""

    STEP_ANALYSIS_WITH_VISION = """
Analyze this automation step using the provided screenshot:

Step Details:
- ID: {step_id}
- Tool: {tool}
- Parameters: {parameters}
- Current Description: {description}

{coordinate_info}

Based on the screenshot, identify:
1. The specific UI element being interacted with
2. The application context and interface
3. Visual details that make the description more precise

Provide ONLY the enhanced description as a single response.
"""

    @classmethod
    def format_analysis_prompt(cls, step_id: str, tool: str, parameters: Dict[str, Any], description: str, has_coordinates: bool = False) -> str:
        """Format the analysis prompt with step details.

        Args:
            step_id: Step identifier
            tool: Tool name being used
            parameters: Tool parameters
            description: Current description
            has_coordinates: Whether the step has x,y coordinates (for red dot indication)

        Returns:
            Formatted prompt string
        """
        coordinate_info = ""
        if has_coordinates and 'x' in parameters and 'y' in parameters:
            coordinate_info = f"Note: A red crosshair has been drawn on the screenshot at coordinates ({parameters['x']}, {parameters['y']}) to indicate the interaction point."

        return cls.STEP_ANALYSIS_WITH_VISION.format(
            step_id=step_id,
            tool=tool,
            parameters=parameters,
            description=description,
            coordinate_info=coordinate_info
        )


class CoreAgent:
    """Service for enhancing step descriptions using AI vision analysis."""

    def __init__(self):
        """Initialize the step description enhancer.

        Args:
            logger: Optional logger instance. If not provided, creates a default logger.
        """
        self._client: AsyncAzureOpenAI = None
        self._agent: Agent = None
        self._runner: Optional[Runner] = None
        self._use_azure_credential = False
        set_tracing_disabled(True)

    async def _initialize_client(self) -> None:
        """Initialize the Azure OpenAI client and agent."""
        if self._client is None:
            # Get configuration from config manager
            azure_config = get_azure_openai_config()

            self._client = await AzureOpenAIClientFactory.create_client(self._use_azure_credential)

            self._agent = Agent(
                name="StepDescriptionEnhancer",
                instructions=AnalysisPromptTemplate.AGENT_INSTRUCTIONS,
                model=OpenAIChatCompletionsModel(
                    model=azure_config.model,
                    openai_client=self._client,
                )
            )

            self._runner = Runner()
            logger.info("Azure OpenAI agent initialized")

    def _convert_image_to_base64(self, image_path: str, x: Optional[int] = None, y: Optional[int] = None) -> str:
        """Convert local image to base64 data URL for OpenAI API, optionally drawing a crosshair.

        Args:
            image_path: Path to the image file
            x: X coordinate to draw crosshair (optional)
            y: Y coordinate to draw crosshair (optional)

        Returns:
            Base64 encoded data URL

        Raises:
            FileNotFoundError: If the image file doesn't exist
            IOError: If there's an error reading the image file
        """
        try:
            image_start_time = time.time()
            logger.info(f"Processing image path: {image_path}")

            # Load the image
            with Image.open(image_path) as image:
                # Keep it simple - use RGB mode (no need for RGBA complexity)
                if image.mode != 'RGB':
                    image = image.convert('RGB')

                # Create a copy to avoid modifying the original
                image_copy = image.copy()

                # Draw crosshair if coordinates are provided
                if x is not None and y is not None:
                    draw = ImageDraw.Draw(image_copy)

                    # Draw a lightweight crosshair instead of filled circles
                    # This is much more performance-friendly and doesn't obscure text
                    crosshair_size = 8
                    line_width = 2

                    # Draw red crosshair lines
                    # Horizontal line
                    draw.line([x - crosshair_size, y, x + crosshair_size, y],
                             fill='red', width=line_width)
                    # Vertical line
                    draw.line([x, y - crosshair_size, x, y + crosshair_size],
                             fill='red', width=line_width)

                    # Optional: Add a small white outline for better visibility
                    draw.line([x - crosshair_size, y, x + crosshair_size, y],
                             fill='white', width=line_width + 2)
                    draw.line([x, y - crosshair_size, x, y + crosshair_size],
                             fill='white', width=line_width + 2)
                    # Redraw red lines on top
                    draw.line([x - crosshair_size, y, x + crosshair_size, y],
                             fill='red', width=line_width)
                    draw.line([x, y - crosshair_size, x, y + crosshair_size],
                             fill='red', width=line_width)

                    logger.info(f"Drew crosshair at coordinates ({x}, {y})")

                    # Save the crosshair image to a temporary location for debugging
                    temp_file = tempfile.NamedTemporaryFile(suffix='_with_crosshair.jpg', delete=False)
                    temp_path = temp_file.name
                    temp_file.close()

                    image_copy.save(temp_path, 'JPEG', quality=95)
                    logger.info(f"Saved crosshair image to temporary location: {temp_path}")

                # Convert to base64 - much simpler now
                buffer = io.BytesIO()
                image_copy.save(buffer, format="JPEG", quality=95)
                encoded_string = base64.b64encode(buffer.getvalue()).decode("utf-8")

                total_image_time = time.time() - image_start_time
                logger.info(f"Image processing completed in {total_image_time:.3f}s")

                return f"data:image/jpeg;base64,{encoded_string}"

        except FileNotFoundError:
            logger.error(f"Screenshot file not found: {image_path}")
            raise
        except Exception as e:
            logger.error(f"Error converting image to base64: {e}")
            raise

    async def _enhance_single_step(self, step: Step) -> str:
        """Enhance description for a single step.

        Args:
            step: Step object to enhance

        Returns:
            Enhanced description string

        Raises:
            ValueError: If step doesn't have required screenshot
            Exception: For API or processing errors
        """
        start_time = time.time()

        try:
            await self._initialize_client()

            if not step.screenshot:
                raise ValueError(f"Step {step.step_id} missing screenshot")

            # Check if step has coordinates for crosshair indication
            has_coordinates = (step.parameters and
                             step.parameters.x is not None and
                             step.parameters.y is not None)

            # Prepare the prompt
            prompt = AnalysisPromptTemplate.format_analysis_prompt(
                step_id=step.step_id,
                tool=step.tool,
                parameters=step.parameters.model_dump(exclude_none=True) if step.parameters else {},
                description=step.description or "No description",
                has_coordinates=has_coordinates
            )

            # Convert screenshot to base64, drawing crosshair if coordinates are present
            x_coord = step.parameters.x if step.parameters else None
            y_coord = step.parameters.y if step.parameters else None
            image_data_url = self._convert_image_to_base64(step.screenshot, x_coord, y_coord)

            # Prepare input for the agent
            input_data = [
                {
                    "role": "user",
                    "content": [
                        {"type": "input_text", "text": prompt},
                        {"type": "input_image", "image_url": image_data_url}
                    ]
                }
            ]

            # Execute enhancement
            api_start = time.time()
            result = await self._runner.run(self._agent, input=input_data)
            api_duration = time.time() - api_start

            enhanced_description = result.final_output.strip()

            # Log performance metrics
            total_duration = time.time() - start_time
            usage = result.context_wrapper.usage

            logger.info(f"Enhanced step {step.step_id} in {total_duration:.2f}s (API: {api_duration:.2f}s, tokens: {usage.input_tokens}/{usage.output_tokens}/{usage.total_tokens})")

            return enhanced_description

        except Exception as e:
            duration = time.time() - start_time
            logger.error(f"Failed to enhance step {step.step_id} after {duration:.2f}s: {e}")
            raise

    @classmethod
    async def enhance_step_description(cls, steps: List[Step], batch_size: int = 5) -> Dict[str, str]:
        """Enhance descriptions for a list of steps.

        Args:
            steps: List of Step objects to enhance
            batch_size: Maximum number of steps to process concurrently (default: 5)

        Returns:
            Dictionary mapping step IDs to enhanced descriptions

        Raises:
            ValueError: If steps list is empty
            Exception: For processing errors
        """
        if not steps:
            raise ValueError("Steps list cannot be empty")

        logger.info(f"Starting enhancement for {len(steps)} steps with batch_size={batch_size}")
        start_time = time.time()

        # Create an instance for this enhancement session
        enhancer = cls()

        try:
            # Process results
            enhanced_descriptions = {}
            successful_count = 0

            # Process steps in batches
            for i in range(0, len(steps), batch_size):
                batch = steps[i:i + batch_size]
                batch_start = time.time()

                # Create tasks for current batch
                tasks = [enhancer._enhance_single_step(step) for step in batch]

                # Execute batch
                results = await asyncio.gather(*tasks, return_exceptions=True)

                # Process batch results
                for step, result in zip(batch, results):
                    if isinstance(result, Exception):
                        logger.error(f"Step {step.step_id} failed: {result}")
                        enhanced_descriptions[step.step_id] = step.description or f"Enhancement failed: {result}"
                    else:
                        enhanced_descriptions[step.step_id] = result
                        successful_count += 1

                batch_duration = time.time() - batch_start
                logger.info(f"Processed batch {i//batch_size + 1} ({len(batch)} steps) in {batch_duration:.2f}s")

            total_duration = time.time() - start_time
            logger.info(f"Enhancement completed: {successful_count}/{len(steps)} successful in {total_duration:.2f}s")

            return enhanced_descriptions

        except Exception as e:
            duration = time.time() - start_time
            logger.error(f"Enhancement process failed after {duration:.2f}s: {e}")
            raise
