#!/usr/bin/env python3
"""
Data Models for VSC-Use v2 Core

Shared data models used across different core modules to avoid circular imports.
"""

from datetime import datetime
from typing import Any, Dict, List, Optional

from pydantic import BaseModel

from .schema import ExecutablePlan, Step


class StepExecutionResult(BaseModel):
    """Result of executing a single step."""
    step_id: str
    agent: str
    tool: str
    description: str
    success: bool = True
    error: Optional[str] = None
    result: Optional[Any] = None
    execution_time: float = 0.0
    action: str = "success"
    before_screenshot: Optional[str] = None
    after_screenshot: Optional[str] = None
    contains_sensitive_data: bool = False  # Flag to indicate if step had environment variables

    @classmethod
    def from_step(cls, step: Step, success: bool = True, error: str = None,
                  result: Any = None, action: str = None, execution_time: float = 0.0):
        """Create result from a Step object."""
        return cls(
            step_id=step.step_id,
            agent=step.agent.value,
            tool=step.tool,
            description=step.description,
            success=success,
            error=error,
            result=result,
            execution_time=execution_time,
            action=action or ("success" if success else "failed")
        )


class PlanExecutionResult(BaseModel):
    """Result of executing a complete plan."""
    plan_id: str
    execution_id: str
    start_time: str
    end_time: Optional[str] = None
    total_items: int
    executed_range: List[int]
    executed_count: int = 0
    success_count: int = 0
    error_count: int = 0
    step_execution_results: List[StepExecutionResult] = []
    errors: List[Dict[str, Any]] = []
    interrupted: bool = False
    exception: Optional[str] = None
    runtime_variables: Dict[str, str] = {}

    @classmethod
    def from_plan(cls, plan: ExecutablePlan, start_index: int,
                  end_index: int, total_items: int):
        """Create result from a plan and execution parameters."""
        return cls(
            plan_id=plan.plan_metadata.plan_id,
            execution_id=f"exec_{datetime.now().strftime('%Y%m%d_%H%M%S')}",
            start_time=datetime.now().isoformat(),
            total_items=total_items,
            executed_range=[start_index, end_index]
        )


class StepReportData(BaseModel):
    """Combined step execution result and step metadata for reporting."""
    execution_result: StepExecutionResult
    step: Step

    @property
    def step_id(self) -> str:
        """Get step ID from execution result."""
        return self.execution_result.step_id

    @property
    def success(self) -> bool:
        """Get success status from execution result."""
        return self.execution_result.success

    @property
    def description(self) -> str:
        """Get description from execution result."""
        return self.execution_result.description

    @property
    def execution_time(self) -> float:
        """Get execution time from execution result."""
        return self.execution_result.execution_time

    @property
    def error(self) -> Optional[str]:
        """Get error from execution result."""
        return self.execution_result.error

    @property
    def tags(self) -> List[str]:
        """Get tags from step metadata."""
        return self.step.tags

    @property
    def contains_sensitive_data(self) -> bool:
        """Get sensitive data flag from execution result."""
        return self.execution_result.contains_sensitive_data

    @classmethod
    def from_execution_and_step(cls, execution_result: StepExecutionResult, step: Step) -> "StepReportData":
        """Create report data from execution result and step."""
        return cls(
            execution_result=execution_result,
            step=step
        )
