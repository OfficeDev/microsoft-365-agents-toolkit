#!/usr/bin/env python3
"""
Agent implementations for vscuse_v2.

This module contains specialized agent implementations that handle different types of operations:
- BaseAgent: Base class providing common functionality for all agents
- FileAgent: Handles file system operations using OpenAI Agents SDK with MCP
- CodeAgent: Handles code execution and script running in Docker containers
- AssertionAgent: Handles assertion evaluation based on screenshots using vision models
- InteractionAgent: Handles UI interactions using Computer interaction tools

Each agent provides a clean interface for executing tools within their domain.
Common functionality is consolidated in the base agent and common modules to reduce redundancy.
"""

from .assertion_agent import AssertionAgent
from .base_agent import BaseAgent
from .code_agent import CodeAgent
from .file_agent import FileAgent
from .interaction_agent import InteractionAgent

__all__ = ['BaseAgent', 'FileAgent', 'CodeAgent', 'AssertionAgent', 'InteractionAgent']
