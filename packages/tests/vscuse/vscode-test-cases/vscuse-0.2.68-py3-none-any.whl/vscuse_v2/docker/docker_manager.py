import logging
import os
from typing import Dict, Tuple

import docker
from docker.errors import DockerException, ImageNotFound
from vscuse_v2.config.config_manager import get_config, get_docker_config


def get_docker_environment_variables() -> Dict[str, str]:
    """
    Get environment variables that should be passed to Docker container.

    Returns:
        Dictionary of environment variable name -> value pairs
    """
    config = get_config()
    docker_config = get_docker_config()

    # Base environment variables (match docker-compose.yml)
    env_vars = {
        'DISPLAY': ':99',
        'SERVICE_PORT': str(docker_config.api_port),
        'DONT_PROMPT_WSL_INSTALL': '1',
    }

    # CI/CD configuration
    cicd_config = config.get_section("cicd")
    if cicd_config and cicd_config.enabled:
        env_vars['CI_ENABLED'] = 'true'
        logging.debug("CI/CD mode enabled for Docker container")
    else:
        env_vars['CI_ENABLED'] = 'false'
        logging.debug("CI/CD mode disabled for Docker container")

    # VS Code Insider configuration
    if docker_config.vscode_insiders:
        env_vars['VSCODE_INSIDERS'] = 'true'
        logging.info("VS Code Insider mode enabled for Docker container")
    else:
        env_vars['VSCODE_INSIDERS'] = 'false'
        logging.debug("VS Code stable version enabled for Docker container")

    # Azure Service Principal configuration
    azure_sp_config = config.get_section("azure_service_principal")
    if azure_sp_config and azure_sp_config.enabled:
        env_vars.update({
            'AZURE_CLIENT_ID': azure_sp_config.client_id,
            'AZURE_CLIENT_SECRET': azure_sp_config.client_secret,
            'AZURE_TENANT_ID': azure_sp_config.tenant_id,
            'AZURE_SUBSCRIPTION_ID': azure_sp_config.subscription_id,
            'AZURE_AUTH_ENABLED': 'true'
        })
        logging.info("Azure Service Principal authentication enabled for Docker container")
    else:
        env_vars['AZURE_AUTH_ENABLED'] = 'false'
        logging.debug("Azure Service Principal authentication disabled")

    # M365 Account credentials (from configuration)
    m365_config = config.get_section("m365")
    if m365_config and m365_config.enabled:
        env_vars.update({
            'M365_ACCOUNT_NAME': m365_config.account_name,
            'M365_ACCOUNT_PASSWORD': m365_config.account_password,
            'M365_TENANT_ID': m365_config.tenant_id,
            'M365_AUTH_ENABLED': 'true'
        })
        logging.info("M365 account authentication enabled for Docker container")
    else:
        env_vars['M365_AUTH_ENABLED'] = 'false'
        logging.debug("M365 account authentication disabled")

    # Azure OpenAI configuration (if needed in container)
    azure_openai_config = config.get_section("azure_openai")
    if azure_openai_config:
        # Only add if not using environment variable substitution syntax
        if not azure_openai_config.endpoint.startswith("${"):
            env_vars['AZURE_OPENAI_ENDPOINT'] = azure_openai_config.endpoint
        if not azure_openai_config.api_key.startswith("${"):
            env_vars['AZURE_OPENAI_API_KEY'] = azure_openai_config.api_key

        env_vars.update({
            'AZURE_OPENAI_API_VERSION': azure_openai_config.api_version,
            'AZURE_OPENAI_MODEL': azure_openai_config.model
        })

    # Custom environment variables from docker.environment config
    if docker_config.environment:
        env_vars.update(docker_config.environment)
        logging.debug(f"Added custom environment variables: {list(docker_config.environment.keys())}")

    return env_vars


def check_docker_running() -> bool:
    """Check if Docker daemon is running and accessible"""
    try:
        client = docker.from_env()
        client.ping()  # type: ignore
        return True
    except (DockerException, ConnectionError, OSError) as e:
        logging.debug(f"Docker daemon check failed: {e}")
        return False


def check_docker_image(image_name: str) -> bool:
    """Check if a Docker image exists locally"""
    try:
        client = docker.from_env()
        client.images.get(image_name)
        return True
    except ImageNotFound:
        return False
    except Exception as e:
        logging.debug(f"Error checking image {image_name}: {e}")
        return False
    finally:
        client.close()


def split_docker_repository_and_tag(image_name: str) -> Tuple[str, str]:
    """Split Docker image name into repository and tag components"""
    if ":" in image_name:
        parts = image_name.rsplit(":", 1)
        return parts[0], parts[1]
    return image_name, "latest"


def pull_vscode_image(image_name: str) -> None:
    """Pull a Docker image from registry"""
    client = docker.from_env()
    repo, tag = split_docker_repository_and_tag(image_name)
    client.images.pull(repo, tag)


def check_vscode_image(image_name: str) -> bool:
    """Check if VSCode image exists, with proper Docker access validation"""
    if not check_docker_running():
        logging.error("Cannot access Docker. Please refer to the Docker installation guide for possible solutions.")
        return False
    return check_docker_image(image_name)


def start_vscode_container(image_name: str, container_name: str, workspace_dir: str, app_dir: str, extensions_dir: str, ports: dict) -> bool:
    """Start the VSCode Docker container with noVNC and extension support"""
    try:
        docker_config = get_docker_config()
        client = docker.from_env()

        # Stop and remove existing container if it exists
        try:
            existing_container = client.containers.get(container_name)
            if existing_container.status == 'running':
                logging.info(f"Stopping existing container: {container_name}")
                existing_container.stop()
            existing_container.remove()
        except docker.errors.NotFound:
            pass  # Container doesn't exist, which is fine

        # Create port mappings (match docker-compose.yml)
        port_bindings = {
            '6080/tcp': ports.get('novnc', docker_config.novnc_port),           # noVNC web interface
            '6081/tcp': ports.get('docker_api', docker_config.api_port), # Screenshot service API
        }

        # Create volume mappings (match docker-compose.yml)
        # Ensure absolute paths for Docker volumes
        workspace_dir_abs = os.path.abspath(workspace_dir)
        app_dir_abs = os.path.abspath(app_dir)
        extensions_dir_abs = os.path.abspath(extensions_dir)

        # Create all directories if they don't exist
        os.makedirs(workspace_dir_abs, exist_ok=True)
        os.makedirs(app_dir_abs, exist_ok=True)
        os.makedirs(extensions_dir_abs, exist_ok=True)

        # Mount volumes to the container - mount directories directly
        volumes = {
            workspace_dir_abs: {'bind': '/workspace', 'mode': 'rw'},
            app_dir_abs: {'bind': '/app/data', 'mode': 'rw'},
            extensions_dir_abs: {'bind': '/tmp/extensions', 'mode': 'ro'}  # Extensions read-only
        }

        # Environment variables (match docker-compose.yml)
        environment = get_docker_environment_variables()

        # Start new container (match docker-compose.yml settings)
        logging.info(f"Starting container: {container_name}")
        container = client.containers.run(
            image_name,
            name=container_name,
            ports=port_bindings,
            volumes=volumes,
            environment=environment,
            cap_add=['SYS_ADMIN'],  # Chrome sandbox capability
            shm_size='512m',  # Chrome needs shared memory for page rendering
            detach=True,
            remove=False,
            restart_policy={'Name': 'no'}  # Don't restart automatically
        )

        logging.info(f"Container {container_name} started successfully with ID: {container.id[:12]}")
        return True

    except Exception as e:
        logging.error(f"Failed to start container: {e}")
        return False


def stop_vscode_container(container_name: str) -> bool:
    """Stop the VSCode Docker container"""
    try:
        client = docker.from_env()
        container = client.containers.get(container_name)
        container.stop()
        container.remove()
        logging.info(f"Container {container_name} stopped and removed")
        return True
    except docker.errors.NotFound:
        logging.info(f"Container {container_name} not found")
        return True  # Not running is fine
    except Exception as e:
        logging.error(f"Failed to stop container: {e}")
        return False


def is_container_running(container_name: str) -> bool:
    """Check if the VSCode container is running"""
    try:
        client = docker.from_env()
        container = client.containers.get(container_name)
        return container.status == 'running'
    except docker.errors.NotFound:
        return False
    except Exception as e:
        logging.error(f"Error checking container status: {e}")
        return False


def get_container_logs(container_name: str, tail: int = 100) -> str:
    """Get container logs"""
    try:
        client = docker.from_env()
        container = client.containers.get(container_name)
        logs = container.logs(tail=tail).decode('utf-8')
        return logs
    except docker.errors.NotFound:
        logging.info(f"Container {container_name} not found")
        return f"Container {container_name} not found"
    except Exception as e:
        logging.error(f"Failed to get container logs: {e}")
        return f"Failed to get container logs: {e}"


def wait_for_container_health(container_name: str, timeout: int = 60) -> bool:
    """Wait for the container to be healthy and ready"""
    import time

    import requests

    docker_config = get_docker_config()
    health_endpoint = f"{docker_config.server_url}/api/v1/health"

    logging.info(f"Waiting for container {container_name} to be ready...")

    for i in range(timeout):
        try:
            # Check if container is running
            if not is_container_running(container_name):
                time.sleep(1)
                continue

            # Check if health endpoint is responding
            response = requests.get(health_endpoint, timeout=2)
            if response.status_code == 200:
                logging.info(f"Container {container_name} is healthy and ready")
                return True
        except requests.RequestException:
            pass  # Service not ready yet

        time.sleep(1)

    logging.warning(f"Container {container_name} did not become healthy within {timeout} seconds")
    return False
