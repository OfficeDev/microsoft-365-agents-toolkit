"""
Docker Client for VscUse

This module provides a client interface to interact with the VscUse Docker Service
running in a containerized VS Code environment.
"""

import time
from enum import Enum
from pathlib import Path
from typing import Dict

import requests

from vscuse_v2.config.config_manager import get_docker_config
from vscuse_v2.utils.logger import setup_logger

logger = setup_logger(__name__)


class DockerServiceError(Exception):
    """Exception raised when Docker service operations fail"""
    pass


class ApiEndpoint(Enum):
    """API endpoints for the Docker service"""
    HEALTH = "/api/v1/health"
    RECORDING_START = "/api/v1/recording/start"
    RECORDING_STOP = "/api/v1/recording/stop"
    RECORDING_STATUS = "/api/v1/recording/status"
    SCREENSHOT = "/api/v1/screenshot"
    INTERACTION_CLICK = "/api/v1/interaction/click"
    INTERACTION_TYPE = "/api/v1/interaction/type_text"
    INTERACTION_KEY = "/api/v1/interaction/key_press"
    INTERACTION_SHORTCUT = "/api/v1/interaction/keyboard_shortcut"
    INTERACTION_MOUSE = "/api/v1/interaction/move_mouse"
    INTERACTION_SCROLL = "/api/v1/interaction/scroll"


class DockerClient:
    """Client for interacting with VscUse Docker Service"""

    def __init__(self, docker_server_url: str = None, timeout: int = None):
        """
        Initialize Docker client

        Args:
            docker_server_url: Full URL of the Docker server (e.g., "http://localhost:6081")
                              If None, uses value from config
            timeout: Request timeout in seconds. If None, uses value from config
        """
        docker_config = get_docker_config()

        self.base_url = (docker_server_url or docker_config.server_url).rstrip('/')
        self.timeout = timeout or docker_config.timeout
        logger.info(f"Docker client initialized for {self.base_url}")

    def _make_request(self, method: str, endpoint: str, **kwargs) -> requests.Response:
        """
        Make HTTP request to Docker service

        Args:
            method: HTTP method (GET, POST, etc.)
            endpoint: API endpoint
            **kwargs: Additional request parameters

        Returns:
            Response object

        Raises:
            DockerServiceError: If request fails
        """
        url = f"{self.base_url}{endpoint}"

        # Use instance timeout if not specified in kwargs
        timeout = kwargs.pop('timeout', self.timeout)

        try:
            response = requests.request(
                method=method,
                url=url,
                timeout=timeout,
                **kwargs
            )
            response.raise_for_status()
            return response

        except requests.exceptions.ConnectionError:
            raise DockerServiceError(
                f"Cannot connect to Docker service at {self.base_url}. "
                f"Make sure the container is running and accessible."
            )
        except requests.exceptions.Timeout:
            raise DockerServiceError(
                f"Request to {url} timed out after {timeout} seconds"
            )
        except requests.exceptions.HTTPError as e:
            raise DockerServiceError(
                f"HTTP error {e.response.status_code}: {e.response.text}"
            )
        except Exception as e:
            raise DockerServiceError(f"Unexpected error: {str(e)}")

    def _execute_interaction(self, endpoint: ApiEndpoint, data: Dict) -> Dict:
        """
        Common method for executing interaction requests with consistent error handling

        Args:
            endpoint: API endpoint enum
            data: Request data

        Returns:
            Response data or error dict
        """
        try:
            response = self._make_request("POST", endpoint.value, json=data)
            return response.json()
        except DockerServiceError as e:
            return {
                "success": False,
                "error": str(e)
            }

    # Health and Service Management
    def _health_check(self) -> Dict:
        """
        Check Docker service health

        Returns:
            Health status information

        Raises:
            DockerServiceError: If health check fails
        """
        logger.debug("Checking Docker service health")

        response = self._make_request("GET", ApiEndpoint.HEALTH.value)
        health_data = response.json()

        if health_data.get("status") != "healthy":
            raise DockerServiceError(
                f"Docker service is unhealthy: {health_data.get('error', 'Unknown error')}"
            )

        logger.info("Docker service is healthy")
        return health_data

    def wait_for_service(self, max_wait: int = 60, check_interval: int = 2) -> bool:
        """
        Wait for Docker service to become available

        Args:
            max_wait: Maximum time to wait in seconds
            check_interval: Time between checks in seconds

        Returns:
            True if service becomes available, False if timeout
        """
        logger.info(f"Waiting for Docker service at {self.base_url}")

        start_time = time.time()
        while time.time() - start_time < max_wait:
            try:
                self._health_check()
                logger.info("Docker service is ready")
                return True
            except DockerServiceError:
                logger.debug(f"Service not ready, waiting {check_interval}s...")
                time.sleep(check_interval)

        logger.error(f"Docker service did not become available within {max_wait}s")
        return False

    def is_service_available(self) -> bool:
        """
        Check if Docker service is available

        Returns:
            True if service is available and healthy
        """
        try:
            self._health_check()
            return True
        except DockerServiceError:
            return False

    # Recording Management
    def start_recording(self) -> Dict:
        """
        Start recording interactions in Docker environment

        Returns:
            Recording session information

        Raises:
            DockerServiceError: If recording start fails
        """
        logger.debug("Starting recording in Docker service")

        response = self._make_request("POST", ApiEndpoint.RECORDING_START.value)
        data = response.json()

        logger.info(f"Recording started - Session: {data.get('session_id', 'unknown')}")
        return data

    def stop_recording(self) -> Dict:
        """
        Stop recording interactions in Docker environment

        Returns:
            Recording session summary

        Raises:
            DockerServiceError: If recording stop fails
        """
        logger.debug("Stopping recording in Docker service")

        response = self._make_request("POST", ApiEndpoint.RECORDING_STOP.value)
        data = response.json()

        logger.info(f"Recording stopped - {data.get('total_interactions', 0)} interactions recorded")
        return data

    def get_recording_status(self) -> Dict:
        """
        Get current recording status from Docker environment

        Returns:
            Recording status information

        Raises:
            DockerServiceError: If status check fails
        """
        logger.debug("Getting recording status from Docker service")

        response = self._make_request("GET", ApiEndpoint.RECORDING_STATUS.value)
        data = response.json()

        logger.debug(f"Recording status: {data.get('status', 'unknown')}")
        return data

    # Computer Interaction Methods
    def click(self, interaction: Dict) -> Dict:
        """Execute a click interaction."""
        data = {
            "x": interaction["x"],
            "y": interaction["y"],
            "button": interaction.get("button", "left").lower(),
            "clicks": 1
        }
        return self._execute_interaction(ApiEndpoint.INTERACTION_CLICK, data)

    def type_text(self, interaction: Dict) -> Dict:
        """Execute a type text interaction."""
        data = {
            "text": interaction.get("text", interaction.get("key", ""))
        }
        return self._execute_interaction(ApiEndpoint.INTERACTION_TYPE, data)

    def key_press(self, interaction: Dict) -> Dict:
        """Execute a key press interaction."""
        data = {
            "key": interaction["key"]
        }
        return self._execute_interaction(ApiEndpoint.INTERACTION_KEY, data)

    def keyboard_shortcut(self, interaction: Dict) -> Dict:
        """Execute a keyboard shortcut interaction."""
        data = {
            "keys": interaction["key"]
        }
        return self._execute_interaction(ApiEndpoint.INTERACTION_SHORTCUT, data)

    def hover(self, interaction: Dict) -> Dict:
        """Execute a hover interaction (move mouse to position)."""
        data = {
            "x": interaction["x"],
            "y": interaction["y"]
        }
        return self._execute_interaction(ApiEndpoint.INTERACTION_MOUSE, data)

    def scroll(self, interaction: Dict) -> Dict:
        """Execute a scroll interaction."""
        data = {
            "x": interaction.get("x", 0),
            "y": interaction.get("y", 0),
            "dx": interaction.get("dx", 0),
            "dy": interaction.get("dy", 3)  # Default scroll down
        }
        return self._execute_interaction(ApiEndpoint.INTERACTION_SCROLL, data)

    # Screenshot Management
    def take_screenshot(self, save_path: str = None) -> str:
        """
        Take a screenshot from the Docker environment

        Args:
            save_path: Path to save the screenshot file (JPEG format). If None, auto-generates path.

        Returns:
            Path to saved file

        Raises:
            DockerServiceError: If screenshot operation fails
        """
        from datetime import datetime

        logger.debug("Taking screenshot from Docker service")

        response = self._make_request("GET", ApiEndpoint.SCREENSHOT.value)
        image_data = response.content

        # Generate path if not provided
        if save_path is None:
            # Use {home}/.vscuse/app/data/temp as the screenshot directory
            home_dir = Path.home()
            screenshot_dir = home_dir / ".vscuse" / "app" / "data" / "temp"
            screenshot_dir.mkdir(parents=True, exist_ok=True)

            # Generate a unique filename with timestamp
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")[:-3]  # milliseconds
            screenshot_filename = f"screenshot_{timestamp}.jpg"
            save_path = str(screenshot_dir / screenshot_filename)

        # Save to file
        save_path = Path(save_path)
        save_path.parent.mkdir(parents=True, exist_ok=True)

        with open(save_path, 'wb') as f:
            f.write(image_data)

        logger.info(f"Screenshot saved to {save_path} ({len(image_data):,} bytes)")
        return str(save_path)
