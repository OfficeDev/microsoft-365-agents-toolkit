#!/usr/bin/env python3
"""
VSC-Use CLI - Command-line interface for plan execution

Provides a `vscuse` command to execute test plans with Docker container management.
"""

import asyncio
import json
import os
import signal
import sys
import time
from pathlib import Path
from typing import Optional

import typer

# Enable UTF-8 mode on Windows to support emoji characters in console output
# This must be set before any I/O operations
if sys.platform == 'win32' and 'PYTHONUTF8' not in os.environ:
    os.environ['PYTHONUTF8'] = '1'
    # Restart the script with UTF-8 mode enabled
    import subprocess
    sys.exit(subprocess.call([sys.executable] + sys.argv))

from vscuse_v2 import __version__
from vscuse_v2.config import get_config, get_docker_config, get_server_config, reset_config
from vscuse_v2.core.executor import Executor
from vscuse_v2.core.models import PlanExecutionResult
from vscuse_v2.core.schema import ExecutablePlan
from vscuse_v2.docker.docker_manager import (
    check_docker_running,
    check_vscode_image,
    get_container_logs,
    is_container_running,
    pull_vscode_image,
    start_vscode_container,
    stop_vscode_container,
    wait_for_container_health,
)
from vscuse_v2.utils.logger import set_log_level_globally, setup_logger
from vscuse_v2.utils.plan_format import convert_from_export_format, resolve_group_references

# Create a Typer application instance
app = typer.Typer(
    help="VSC-Use CLI: Execute test plans with Docker container automation.",
    add_completion=False
)

logger = setup_logger(__name__)


# Global variable to track the container name for cleanup
_container_name = None


def cleanup_container():
    """Cleanup function to stop Docker container on exit"""
    if _container_name:
        try:
            if is_container_running(_container_name):
                print(f"Signal cleanup: Stopping container {_container_name}...")
                stop_vscode_container(_container_name)
        except Exception as e:
            print(f"Warning: Failed to cleanup container: {e}")


def setup_cleanup_handlers(container_name: str):
    """Setup cleanup handlers for graceful shutdown"""
    global _container_name
    _container_name = container_name

    # Register cleanup function to run on normal exit
    import atexit
    atexit.register(cleanup_container)

    # Register signal handlers for graceful shutdown (Unix-like systems)
    if hasattr(signal, 'SIGTERM'):
        signal.signal(signal.SIGTERM, lambda signum, frame: sys.exit(0))
    if hasattr(signal, 'SIGINT'):
        signal.signal(signal.SIGINT, lambda signum, frame: sys.exit(0))


@app.command()
def execute(
    plan_path: str = typer.Argument(..., help="Path to the test plan JSON file"),
    config_file: Optional[str] = typer.Option(None, "--config-file", "-c", help="Path to the config file"),
    groups_dir: Optional[str] = typer.Option(None, "--groups-dir", "-g", help="Directory containing group plan files"),
    start_index: int = typer.Option(0, "--start", "-s", help="Start execution from step index"),
    end_index: Optional[int] = typer.Option(None, "--end", "-e", help="End execution at step index"),
    generate_report: bool = typer.Option(True, "--report/--no-report", help="Generate HTML test report"),
    report_dir: str = typer.Option("test_report", "--report-dir", help="Directory for test report output"),
):
    """Execute a test plan with Docker container automation."""
    # Initialize configuration with custom config file if provided
    if config_file:
        reset_config()
        get_config(config_file)

    # Set up logging based on config
    from vscuse_v2.config.config_manager import get_logging_config
    set_log_level_globally(get_logging_config().level)

    typer.echo(typer.style(f"Starting VSC-Use CLI v{__version__}", fg=typer.colors.GREEN, bold=True))

    # Validate plan file
    plan_file = Path(plan_path)
    if not plan_file.exists():
        typer.echo(typer.style(f"Error: Plan file not found: {plan_path}", fg=typer.colors.RED))
        raise typer.Exit(1)

    try:
        # Load and validate the plan first
        with open(plan_file, 'r', encoding='utf-8') as f:
            plan_data = json.load(f)

        # Resolve group references if groups directory is provided
        if groups_dir:
            try:
                plan_data = resolve_group_references(plan_data, groups_dir)
                typer.echo(f"Successfully resolved group references from: {groups_dir}")
            except FileNotFoundError as e:
                typer.echo(typer.style(f"Error: {e}", fg=typer.colors.RED))
                raise typer.Exit(1)
            except Exception as e:
                typer.echo(typer.style(f"Error resolving group references: {e}", fg=typer.colors.RED))
                raise typer.Exit(1)

        # Process exported plan format with separated screenshots section
        plan_data = convert_from_export_format(plan_data)

        plan = ExecutablePlan.model_validate(plan_data)

        # Validate plan logic and structure
        validation_errors = plan.validate_plan()
        if validation_errors:
            typer.echo(typer.style("Plan validation failed:", fg=typer.colors.RED, bold=True))
            for error in validation_errors:
                typer.echo(f"  - {error}")
            raise typer.Exit(1)

        # Setup Docker container
        setup_docker_environment()

        # Execute the plan
        asyncio.run(execute_plan_async(
            plan=plan,  # Pass the already loaded plan
            plan_file=plan_file,
            start_index=start_index,
            end_index=end_index,
            generate_report=generate_report,
            report_dir=report_dir
        ))

    except KeyboardInterrupt:
        typer.echo("\nExecution interrupted by user")
        raise typer.Exit(1)
    except Exception as e:
        typer.echo(typer.style(f"Execution failed: {e}", fg=typer.colors.RED))
        logger.exception("Execution failed")
        raise typer.Exit(1)
    finally:
        # Cleanup Docker container
        cleanup_docker_environment()

@app.command()
def version():
    """Show version information."""
    typer.echo(f"VSC-Use CLI version: {__version__}")


@app.callback()
def main():
    """VSC-Use CLI: Execute test plans with Docker container automation."""
    pass


def setup_docker_environment():
    """Setup Docker environment and start container."""
    typer.echo("Setting up Docker environment...")

    # Get configuration sections using convenience functions
    docker_config = get_docker_config()

    # Check Azure Service Principal configuration
    config = get_config()
    azure_sp_config = config.get_section("azure_service_principal")
    if azure_sp_config and azure_sp_config.enabled:
        typer.echo(typer.style("Azure Service Principal authentication: ENABLED", fg=typer.colors.CYAN))
        typer.echo(f"  Client ID: {azure_sp_config.client_id[:8]}...")
        typer.echo(f"  Tenant ID: {azure_sp_config.tenant_id[:8]}...")
    else:
        typer.echo(typer.style("Azure Service Principal authentication: DISABLED", fg=typer.colors.YELLOW))

    # Check if Docker is running
    typer.echo(typer.style("Checking if Docker is running...", fg=typer.colors.CYAN), nl=False)
    if not check_docker_running():
        typer.echo(typer.style(" Failed", fg=typer.colors.RED, bold=True))
        typer.echo("Docker is not running. Please start Docker and try again.")
        raise typer.Exit(1)
    else:
        typer.echo(typer.style(" OK", fg=typer.colors.GREEN, bold=True))

    # Check and pull Docker image if needed
    vscode_image = docker_config.image_name
    typer.echo(typer.style(f"Checking Docker VSCode image ({vscode_image})...", fg=typer.colors.CYAN), nl=False)
    if not check_vscode_image(vscode_image):
        typer.echo(typer.style(" Pulling", fg=typer.colors.YELLOW, bold=True))
        typer.echo(f"Pulling Docker image: {vscode_image} (this may take a few minutes)")
        try:
            pull_vscode_image(vscode_image)
            typer.echo(typer.style("Image pulled successfully", fg=typer.colors.GREEN))
        except Exception as e:
            typer.echo(typer.style(f"Failed to pull image: {e}", fg=typer.colors.RED, bold=True))
            raise typer.Exit(1)
    else:
        typer.echo(typer.style(" OK", fg=typer.colors.GREEN, bold=True))

    # Create workspace directories
    Path(docker_config.workspace_dir).mkdir(parents=True, exist_ok=True)
    Path(docker_config.app_dir).mkdir(parents=True, exist_ok=True)
    Path(docker_config.extensions_dir).mkdir(parents=True, exist_ok=True)

    # Setup cleanup handlers
    setup_cleanup_handlers(docker_config.container_name)

    # Start VSCode container (always restart if running)
    typer.echo(f"Starting VSCode container ({docker_config.container_name})...", nl=False)

    # Stop existing container if running
    if is_container_running(docker_config.container_name):
        typer.echo(typer.style(" Restarting", fg=typer.colors.YELLOW, bold=True))
        typer.echo(f"Stopping existing container ({docker_config.container_name})...", nl=False)
        if stop_vscode_container(docker_config.container_name):
            typer.echo(typer.style(" Stopped", fg=typer.colors.GREEN, bold=True))
        else:
            typer.echo(typer.style(" Failed to stop", fg=typer.colors.YELLOW, bold=True))
        typer.echo(f"Starting new container ({docker_config.container_name})...", nl=False)

    # Create ports dict
    ports = {
        'novnc': docker_config.novnc_port,
        'docker_api': docker_config.api_port,
        'vscuse_api': get_server_config().api_port,
    }

    if start_vscode_container(
        vscode_image,
        docker_config.container_name,
        docker_config.workspace_dir,
        docker_config.app_dir,
        docker_config.extensions_dir,
        ports
    ):
        typer.echo(typer.style(" Started", fg=typer.colors.GREEN, bold=True))

        # Wait for container to be ready
        typer.echo("Waiting for VSCode container to be ready...", nl=False)
        if wait_for_container_health(docker_config.container_name, timeout=60):
            typer.echo(typer.style(" Ready", fg=typer.colors.GREEN, bold=True))
        else:
            typer.echo(typer.style(" Timeout", fg=typer.colors.YELLOW, bold=True))
            typer.echo("Container started but health check timed out. Continuing anyway...")
    else:
        typer.echo(typer.style(" Failed", fg=typer.colors.RED, bold=True))
        raise typer.Exit(1)

    # Display service URLs
    typer.echo()
    typer.echo(typer.style("VSC-Use Services:", fg=typer.colors.CYAN, bold=True))
    typer.echo(f"  noVNC Viewer:    http://localhost:{docker_config.novnc_port}")
    typer.echo(f"  Docker API:      http://localhost:{docker_config.api_port}")
    typer.echo()


def cleanup_docker_environment():
    """Cleanup Docker environment."""
    from vscuse_v2.config.config_manager import get_logging_config

    docker_config = get_docker_config()
    logging_config = get_logging_config()
    # typer.echo("\nPress Enter to clean up Docker environment...")
    # try:
    #     input()  # Wait for user to press Enter
    # except (KeyboardInterrupt, EOFError):
    #     # Handle Ctrl+C or EOF gracefully
    #     typer.echo("\nProceeding with cleanup...")

    typer.echo("Cleaning up Docker environment...")

    # Print container logs before stopping if enabled in config
    if logging_config.print_docker_logs and is_container_running(docker_config.container_name):
        typer.echo(f"Getting logs for container ({docker_config.container_name})...")
        logs = get_container_logs(docker_config.container_name, tail=logging_config.docker_log_tail)
        typer.echo(typer.style("Container Logs:", fg=typer.colors.CYAN, bold=True))
        typer.echo("=" * 50)
        typer.echo(logs)
        typer.echo("=" * 50)

    typer.echo(f"Stopping VSCode container ({docker_config.container_name})...", nl=False)
    if stop_vscode_container(docker_config.container_name):
        typer.echo(typer.style(" Stopped", fg=typer.colors.GREEN, bold=True))
    else:
        typer.echo(typer.style(" Failed", fg=typer.colors.YELLOW, bold=True))


async def execute_plan_async(
    plan: ExecutablePlan,
    plan_file: Path,
    start_index: int = 0,
    end_index: Optional[int] = None,
    generate_report: bool = True,
    report_dir: str = "test_report"
):
    """Execute the plan asynchronously."""
    typer.echo(f"Executing plan: {plan.plan_metadata.name}")

    # Display plan information
    display_plan_info(plan, start_index, end_index)

    # Create and configure executor
    docker_server_url = get_docker_config().server_url
    async with Executor(
        docker_server_url=docker_server_url,
        generate_report=generate_report,
        report_output_dir=report_dir
    ) as executor:

        # Store plan path for report generation
        executor.current_plan_path = plan_file

        # Execute the plan
        start_time = time.time()
        result = await executor.execute_plan(
            plan=plan,
            start_index=start_index,
            end_index=end_index
        )
        execution_time = time.time() - start_time

        # Display results and handle exit codes
        display_execution_results(result, execution_time)
        handle_execution_exit_codes(result)


def display_plan_info(plan: ExecutablePlan, start_index: int, end_index: Optional[int]):
    """Display plan information to user."""
    typer.echo(f"Plan loaded: {plan.plan_metadata.name}")
    typer.echo(f"Description: {plan.plan_metadata.description}")
    typer.echo(f"Total steps: {len(plan.steps)}")

    if end_index is None:
        end_index = len(plan.steps)

    typer.echo(f"Executing steps {start_index} to {end_index}")
    typer.echo()


def display_execution_results(result: PlanExecutionResult, execution_time: float):
    """Display execution results to user."""
    typer.echo()
    typer.echo(typer.style("Execution Summary:", fg=typer.colors.CYAN, bold=True))
    typer.echo(f"Plan ID: {result.plan_id}")
    typer.echo(f"Execution ID: {result.execution_id}")
    typer.echo(f"Execution time: {execution_time:.2f}s")
    typer.echo(f"Total steps: {result.total_items}")
    typer.echo(f"Steps executed: {result.executed_count}")
    typer.echo(f"Successful: {result.success_count}")
    typer.echo(f"Errors: {result.error_count}")

    if result.executed_count > 0:
        success_rate = result.success_count / result.executed_count * 100
        typer.echo(f"Success rate: {success_rate:.1f}%")

    # Display runtime variables if any (only var type, not env/secret/mfa_code)
    if result.runtime_variables:
        typer.echo()
        typer.echo(typer.style("Runtime Variables:", fg=typer.colors.CYAN, bold=True))
        for name, value in sorted(result.runtime_variables.items()):
            typer.echo(f"  {name}: {value}")

    # Display errors if any
    if result.errors:
        typer.echo()
        typer.echo(typer.style("Errors:", fg=typer.colors.RED, bold=True))
        for error in result.errors:
            typer.echo(f"  Step {error['step_id']}: {error['error']}")


def handle_execution_exit_codes(result: PlanExecutionResult):
    """Handle exit codes based on execution results."""
    # Check if execution was interrupted or had exceptions
    if result.interrupted:
        typer.echo(typer.style("Execution was interrupted", fg=typer.colors.YELLOW))
        raise typer.Exit(1)

    if result.exception:
        typer.echo(typer.style(f"Execution exception: {result.exception}", fg=typer.colors.RED))
        raise typer.Exit(1)

    # Exit with error code if there were failures
    if result.error_count > 0:
        raise typer.Exit(1)

    typer.echo(typer.style("Execution completed successfully!", fg=typer.colors.GREEN, bold=True))


def run():
    """
    Main entry point called by the 'vscuse' command.
    This function should be referenced in pyproject.toml's [project.scripts] section.
    """
    app()


if __name__ == "__main__":
    app()
