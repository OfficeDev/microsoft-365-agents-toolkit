"""
Shared Azure OpenAI client utilities
"""

import os

from openai import AsyncAzureOpenAI

from vscuse_v2.utils.logger import setup_logger

logger = setup_logger(__name__)


class AzureOpenAIClientFactory:
    """Factory for creating Azure OpenAI clients with consistent configuration"""

    @staticmethod
    async def create_client(use_azure_credential: bool = False) -> AsyncAzureOpenAI:
        """Create and return an Azure OpenAI client.

        Args:
            use_azure_credential: Whether to use Azure credential authentication (default: False)

        Returns:
            AsyncAzureOpenAI: Configured client instance

        Raises:
            ImportError: If azure-identity package is required but not installed
            RuntimeError: If required environment variables are missing
        """
        # Lazy import to avoid circular dependency
        try:
            from vscuse_v2.config import get_azure_openai_config
            azure_config = get_azure_openai_config()
        except ImportError:
            # Fallback to environment variables if config is not available
            logger.warning("Config system not available, falling back to environment variables")
            azure_config = None

        if use_azure_credential:
            # Use Azure credential authentication
            try:
                from azure.identity import DefaultAzureCredential, get_bearer_token_provider

                token_provider = get_bearer_token_provider(
                    DefaultAzureCredential(),
                    "https://cognitiveservices.azure.com/.default"
                )

                # Get endpoint from config or fallback to env
                endpoint = azure_config.endpoint if azure_config else os.getenv("AZURE_OPENAI_ENDPOINT")
                api_version = azure_config.api_version if azure_config else os.getenv("AZURE_OPENAI_API_VERSION", "2025-04-01-preview")

                client = AsyncAzureOpenAI(
                    azure_endpoint=endpoint,
                    api_version=api_version,
                    azure_ad_token_provider=token_provider,
                )
                logger.info("Azure OpenAI client initialized with Azure credential")
                return client

            except ImportError:
                logger.error("azure-identity package not installed. Install with: pip install azure-identity")
                raise
        else:
            # Use API key authentication
            if azure_config:
                # Use config values
                api_key = azure_config.api_key
                endpoint = azure_config.endpoint
                api_version = azure_config.api_version
            else:
                # Fallback to environment variables
                api_key = os.getenv("AZURE_OPENAI_API_KEY")
                endpoint = os.getenv("AZURE_OPENAI_ENDPOINT")
                api_version = os.getenv("AZURE_OPENAI_API_VERSION", "2025-04-01-preview")

            if not api_key or (isinstance(api_key, str) and api_key.startswith("${")):
                raise RuntimeError("AZURE_OPENAI_API_KEY environment variable is required")
            if not endpoint or (isinstance(endpoint, str) and endpoint.startswith("${")):
                raise RuntimeError("AZURE_OPENAI_ENDPOINT environment variable is required")

            client = AsyncAzureOpenAI(
                api_key=api_key,
                api_version=api_version,
                azure_endpoint=endpoint
            )
            logger.info("Azure OpenAI client initialized with API key")
            return client
