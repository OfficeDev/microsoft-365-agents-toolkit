#!/usr/bin/env python3
"""
Image Analysis Tools

Utilities for image comparison, stability detection, and UI state analysis.
Focused on screenshot comparison for automation and loading detection.
"""

import base64
import mimetypes
import os
from pathlib import Path

from vscuse_v2.utils.logger import setup_logger

logger = setup_logger(__name__)


def detect_loading_stability(img_path1: str, img_path2: str) -> float:
    """Detect if UI is stable (not loading) by comparing structural content changes.

    Enhanced algorithm that properly detects loading states while ignoring minor UI artifacts
    like cursor blinking, text selection, hover effects.

    Args:
        img_path1: Path to first screenshot
        img_path2: Path to second screenshot

    Returns:
        float: Stability ratio between 0.0 and 1.0 (higher = more stable)
    """
    try:
        import os

        import numpy as np
        from PIL import Image, ImageChops

        # First check file size for quick loading detection
        size1 = os.path.getsize(img_path1)
        size2 = os.path.getsize(img_path2)

        if max(size1, size2) > 0:
            size_diff_ratio = abs(size1 - size2) / max(size1, size2)

            # Large file size differences often indicate loading/content changes
            if size_diff_ratio > 0.10:  # > 10% size difference
                logger.debug(f"Large file size difference: {size_diff_ratio:.4f} - likely loading")
                # Don't return immediately, but bias toward instability
                size_penalty = min(0.3, size_diff_ratio)
            elif size_diff_ratio > 0.02:  # 2-10% size difference
                logger.debug(f"Moderate file size difference: {size_diff_ratio:.4f} - possible loading")
                size_penalty = min(0.1, size_diff_ratio / 2)
            else:
                logger.debug(f"Small file size difference: {size_diff_ratio:.4f} - likely minor change")
                size_penalty = 0.0
        else:
            size_penalty = 0.0

        # Load and compare images
        img1 = Image.open(img_path1)
        img2 = Image.open(img_path2)

        # Different dimensions = definitely loading/layout changes
        if img1.size != img2.size:
            logger.debug(f"UI layout changed: {img1.size} -> {img2.size}")
            return 0.0

        # Convert to RGB for comparison
        if img1.mode != 'RGB':
            img1 = img1.convert('RGB')
        if img2.mode != 'RGB':
            img2 = img2.convert('RGB')

        # Calculate difference focusing on structural changes
        diff = ImageChops.difference(img1, img2)
        diff_gray = diff.convert('L')
        diff_array = np.array(diff_gray)

        total_pixels = diff_array.size
        if total_pixels == 0:
            return 1.0

        # Multi-level change detection
        identical_pixels = np.count_nonzero(diff_array == 0)
        # any_change_pixels = np.count_nonzero(diff_array > 0)
        minor_change_pixels = np.count_nonzero((diff_array > 0) & (diff_array <= 5))
        cursor_level_pixels = np.count_nonzero((diff_array > 5) & (diff_array <= 15))
        significant_pixels = np.count_nonzero((diff_array > 15) & (diff_array <= 50))
        major_change_pixels = np.count_nonzero(diff_array > 50)

        # Calculate ratios
        identical_ratio = identical_pixels / total_pixels
        minor_ratio = minor_change_pixels / total_pixels
        cursor_ratio = cursor_level_pixels / total_pixels
        significant_ratio = significant_pixels / total_pixels
        major_ratio = major_change_pixels / total_pixels

        # Enhanced loading detection logic
        if major_ratio > 0.01:  # > 1% major changes
            stability = 0.2  # Definitely loading/major change
            logger.debug(f"Major changes detected: {major_ratio:.4f} - loading state")
        elif significant_ratio > 0.02:  # > 2% significant changes
            stability = 0.4  # Likely loading
            logger.debug(f"Significant changes detected: {significant_ratio:.4f} - likely loading")
        elif (significant_ratio + major_ratio) > 0.005:  # > 0.5% significant+major changes
            stability = 0.7  # Possible loading or major UI change
            logger.debug(f"Moderate changes detected: {significant_ratio + major_ratio:.4f} - possible loading")
        elif cursor_ratio > 0.005:  # > 0.5% cursor-level changes
            # Could be cursor blinking, loading spinner, or small animation
            if cursor_ratio < 0.02:  # < 2% cursor-level changes
                stability = 0.92  # Likely minor UI artifact
                logger.debug(f"Minor UI changes: {cursor_ratio:.4f} - likely cursor/animation")
            else:
                stability = 0.8  # More changes, could be loading
                logger.debug(f"Multiple UI changes: {cursor_ratio:.4f} - possible loading")
        else:
            # Very few changes - likely stable
            stability = 0.98
            logger.debug("Minimal changes detected - UI stable")

        # Apply file size penalty
        final_stability = max(0.0, stability - size_penalty)

        # Detailed logging
        logger.debug("Loading stability analysis:")
        logger.debug(f"  Identical: {identical_ratio:.4f}, Minor: {minor_ratio:.4f}")
        logger.debug(f"  Cursor-level: {cursor_ratio:.4f}, Significant: {significant_ratio:.4f}, Major: {major_ratio:.4f}")
        logger.debug(f"  Size penalty: {size_penalty:.4f}, Final stability: {final_stability:.4f}")

        return final_stability

    except Exception as e:
        logger.warning(f"Error in loading stability detection: {e}")
        # Enhanced fallback with file size consideration
        try:
            import os
            size1 = os.path.getsize(img_path1)
            size2 = os.path.getsize(img_path2)

            if size1 == size2:
                # Same size - check byte content
                with open(img_path1, 'rb') as f1, open(img_path2, 'rb') as f2:
                    return 1.0 if f1.read() == f2.read() else 0.85
            else:
                # Different sizes - check how different
                size_diff = abs(size1 - size2) / max(size1, size2) if max(size1, size2) > 0 else 0
                if size_diff > 0.1:  # > 10% difference
                    return 0.3  # Likely loading
                elif size_diff > 0.02:  # 2-10% difference
                    return 0.7  # Possible loading
                else:
                    return 0.9  # Minor difference
        except:
            return 0.5  # Unknown state


def calculate_image_similarity(img1_path: str, img2_path: str) -> dict:
    """Calculate comprehensive similarity metrics between two images.

    Args:
        img1_path: Path to first image
        img2_path: Path to second image

    Returns:
        dict: Dictionary containing various similarity metrics and analysis
    """
    try:
        import numpy as np
        from PIL import Image, ImageChops

        # Load images
        img1 = Image.open(img1_path)
        img2 = Image.open(img2_path)

        # Basic validation
        if img1.size != img2.size:
            return {
                'size_match': False,
                'similarity': 0.0,
                'error': f'Size mismatch: {img1.size} vs {img2.size}'
            }

        # Convert to RGB for consistent comparison
        if img1.mode != 'RGB':
            img1 = img1.convert('RGB')
        if img2.mode != 'RGB':
            img2 = img2.convert('RGB')

        # Calculate difference
        diff = ImageChops.difference(img1, img2)
        diff_array = np.array(diff)

        # Statistical analysis
        mean_diff = np.mean(diff_array)
        max_diff = np.max(diff_array)
        std_diff = np.std(diff_array)

        # Pixel-level analysis
        total_pixels = diff_array.size
        changed_pixels = np.count_nonzero(diff_array)
        unchanged_pixels = total_pixels - changed_pixels

        # Calculate similarity metrics
        mean_similarity = 1.0 - (mean_diff / 255.0)
        pixel_similarity = unchanged_pixels / total_pixels

        # Combined similarity score
        overall_similarity = (mean_similarity + pixel_similarity) / 2.0

        return {
            'size_match': True,
            'similarity': overall_similarity,
            'mean_similarity': mean_similarity,
            'pixel_similarity': pixel_similarity,
            'changed_pixels': changed_pixels,
            'changed_pixel_ratio': changed_pixels / total_pixels,
            'mean_difference': mean_diff,
            'max_difference': max_diff,
            'std_difference': std_diff,
            'is_identical': changed_pixels == 0,
            'is_very_similar': overall_similarity > 0.95,
            'is_similar': overall_similarity > 0.90
        }

    except Exception as e:
        return {
            'size_match': False,
            'similarity': 0.0,
            'error': str(e)
        }


def detect_cursor_blinking(img1_path: str, img2_path: str, threshold: float = 0.98) -> bool:
    """Detect if the difference between two images is likely just cursor blinking.

    Args:
        img1_path: Path to first image
        img2_path: Path to second image
        threshold: Similarity threshold for cursor blink detection

    Returns:
        bool: True if difference is likely cursor blinking, False otherwise
    """
    try:
        similarity_data = calculate_image_similarity(img1_path, img2_path)

        if not similarity_data.get('size_match', False):
            return False

        # Cursor blinking characteristics:
        # 1. High overall similarity (> 98%)
        # 2. Very few changed pixels (< 0.1% of image)
        # 3. Small file size difference

        is_highly_similar = similarity_data.get('similarity', 0) > threshold
        has_few_changes = similarity_data.get('changed_pixel_ratio', 1) < 0.001

        # Check file size difference
        import os
        size1 = os.path.getsize(img1_path)
        size2 = os.path.getsize(img2_path)
        size_diff_ratio = abs(size1 - size2) / max(size1, size2) if max(size1, size2) > 0 else 0
        has_small_size_diff = size_diff_ratio < 0.005  # < 0.5% size difference

        is_cursor_blink = is_highly_similar and has_few_changes and has_small_size_diff

        logger.debug(f"Cursor blink analysis: similarity={similarity_data.get('similarity', 0):.4f}, "
                    f"changed_pixels={similarity_data.get('changed_pixel_ratio', 0):.6f}, "
                    f"size_diff={size_diff_ratio:.6f}, is_cursor_blink={is_cursor_blink}")

        return is_cursor_blink

    except Exception as e:
        logger.warning(f"Error in cursor blink detection: {e}")
        return False


def get_image_info(img_path: str) -> dict:
    """Get basic information about an image file.

    Args:
        img_path: Path to image file

    Returns:
        dict: Dictionary containing image information
    """
    try:
        import os

        from PIL import Image

        # File information
        file_size = os.path.getsize(img_path)

        # Image information
        with Image.open(img_path) as img:
            return {
                'path': img_path,
                'file_size': file_size,
                'dimensions': img.size,
                'width': img.width,
                'height': img.height,
                'mode': img.mode,
                'format': img.format,
                'has_transparency': 'transparency' in img.info or 'A' in img.mode,
                'pixel_count': img.width * img.height
            }

    except Exception as e:
        return {
            'path': img_path,
            'error': str(e)
        }


# Convenience functions for common use cases
def is_ui_stable(img1_path: str, img2_path: str, stability_threshold: float = 0.90) -> bool:
    """Check if UI is stable between two screenshots.

    Args:
        img1_path: Path to first screenshot
        img2_path: Path to second screenshot
        stability_threshold: Minimum stability ratio to consider stable

    Returns:
        bool: True if UI appears stable, False if loading/changing
    """
    stability = detect_loading_stability(img1_path, img2_path)
    return stability >= stability_threshold


def are_images_identical(img1_path: str, img2_path: str) -> bool:
    """Check if two images are identical at pixel level.

    Args:
        img1_path: Path to first image
        img2_path: Path to second image

    Returns:
        bool: True if images are identical, False otherwise
    """
    similarity_data = calculate_image_similarity(img1_path, img2_path)
    return similarity_data.get('is_identical', False)


def are_images_similar(img1_path: str, img2_path: str, threshold: float = 0.90) -> bool:
    """Check if two images are similar above a threshold.

    Args:
        img1_path: Path to first image
        img2_path: Path to second image
        threshold: Similarity threshold (0.0 to 1.0)

    Returns:
        bool: True if images are similar above threshold, False otherwise
    """
    similarity_data = calculate_image_similarity(img1_path, img2_path)
    return similarity_data.get('similarity', 0.0) >= threshold


def convert_image_to_data_uri(image_path: str) -> str:
    """Convert an image file to data URI format.

    Args:
        image_path: Path to the image file

    Returns:
        str: Data URI string or None if conversion fails
    """
    try:
        if not image_path or not os.path.exists(image_path):
            logger.warning(f"Image file not found: {image_path}")
            return None

        file_path = Path(image_path)
        mime_type, _ = mimetypes.guess_type(image_path)
        if not mime_type or not mime_type.startswith('image/'):
            mime_type = 'image/jpeg'  # default fallback

        with open(image_path, 'rb') as image_file:
            image_data = image_file.read()
            base64_data = base64.b64encode(image_data).decode('utf-8')

        data_uri = f"data:{mime_type};base64,{base64_data}"
        logger.debug(f"Converted image to data URI: {file_path.name} ({len(image_data)} bytes)")
        return data_uri

    except Exception as e:
        logger.error(f"Failed to convert image to data URI: {e}")
        return None
