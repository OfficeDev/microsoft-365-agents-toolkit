#!/usr/bin/env python3
"""
Project Scanner for VSC-Use

Scans a project directory for executable plan JSON files and imports them
with full path tracking in the file index.
"""

import json
from pathlib import Path
from typing import Callable, List, Optional, Tuple

from vscuse_v2.config.config_manager import get_execution_config
from vscuse_v2.server.database import Step, get_database
from vscuse_v2.utils.logger import setup_logger
from vscuse_v2.utils.plan_format import convert_from_export_format

logger = setup_logger(__name__)


def scan_and_import_plans(
    project_path: str,
    filter_fn: Optional[Callable[[dict], bool]] = None
) -> Tuple[int, int, List[str]]:
    """
    Scan a project directory for plan JSON files and import them with optional filtering.

    Args:
        project_path: Path to the project directory to scan
        filter_fn: Optional function to filter plans. Takes plan_metadata dict and returns bool.
                   If None, all valid plans are imported.

    Returns:
        Tuple of (success_count, skip_count, error_messages)
    """
    project_dir = Path(project_path).resolve()

    if not project_dir.exists():
        logger.error(f"Project path does not exist: {project_dir}")
        return 0, 0, [f"Project path does not exist: {project_dir}"]

    if not project_dir.is_dir():
        logger.error(f"Project path is not a directory: {project_dir}")
        return 0, 0, [f"Project path is not a directory: {project_dir}"]

    logger.info(f"Scanning project directory: {project_dir}")

    # Find all JSON files recursively
    json_files = list(project_dir.rglob("*.json"))
    logger.info(f"Found {len(json_files)} JSON files")

    db = get_database()
    success_count = 0
    skip_count = 0
    errors = []

    for json_file in json_files:
        try:
            # Read and validate the file
            with open(json_file, 'r', encoding='utf-8') as f:
                data = json.load(f)

            # Check if it's a valid plan file
            if 'plan_metadata' not in data or 'steps' not in data:
                logger.debug(f"Skipping {json_file.name}: not a plan file")
                skip_count += 1
                continue

            plan_metadata = data['plan_metadata']
            plan_id = plan_metadata.get('plan_id')

            if not plan_id:
                logger.warning(f"Skipping {json_file.name}: missing plan_id")
                skip_count += 1
                continue

            # Apply filter if provided
            if filter_fn and not filter_fn(plan_metadata):
                logger.debug(f"Skipping {json_file.name}: filtered out")
                skip_count += 1
                continue

            # Process the import data (handle screenshots if present)
            processed_data = convert_from_export_format(data)

            # Get default execution context
            execution_config = get_execution_config()
            default_execution_context = {
                'delay_between_steps': execution_config.delay_between_steps,
                'stop_on_error': execution_config.stop_on_error,
                'precondition_wait_timeout': execution_config.precondition_wait_timeout,
                'precondition_retry_interval': execution_config.precondition_retry_interval,
                'step_retry_timeout': execution_config.step_retry_timeout
            }

            # Check if plan already exists
            existing_plan = db.get_plan_metadata(plan_id)

            if existing_plan:
                # Update existing plan - similar to import endpoint
                logger.info(f"Plan {plan_id} already exists, updating it")

                # Update plan metadata
                db.update_plan_metadata(
                    plan_id=plan_id,
                    name=plan_metadata.get('name', 'Untitled Plan'),
                    description=plan_metadata.get('description', ''),
                    version=plan_metadata.get('version', '1.0'),
                    execution_context=plan_metadata.get('execution_context', default_execution_context),
                    execution_order=plan_metadata.get('execution_order', []),
                    total_steps=plan_metadata.get('total_steps', 0),
                    tags=plan_metadata.get('tags', [])
                )

                # Clean up existing steps (like import endpoint does)
                with db.get_session() as session:
                    session.query(Step).filter(Step.plan_id == plan_id).delete()
                    session.commit()
            else:
                # Create new plan - similar to import endpoint
                logger.info(f"Creating new plan {plan_id}")

                # Create plan metadata
                created_plan = db.create_plan_metadata(
                    plan_id=plan_id,
                    name=plan_metadata.get('name', 'Untitled Plan'),
                    description=plan_metadata.get('description', ''),
                    version=plan_metadata.get('version', '1.0'),
                    execution_context=plan_metadata.get('execution_context', default_execution_context),
                    execution_order=plan_metadata.get('execution_order', []),
                    total_steps=plan_metadata.get('total_steps', 0),
                    tags=plan_metadata.get('tags', [])
                )

                if not created_plan:
                    errors.append(f"{json_file.name}: Failed to create plan metadata")
                    continue

            # Create steps with original IDs from file (same for both create and update)
            for step_data in processed_data['steps']:
                original_step_id = step_data.get('step_id')
                if not original_step_id:
                    logger.warning(f"Skipping step without step_id in plan {plan_id}")
                    continue

                try:
                    db.create_step(
                        step_id=original_step_id,
                        plan_id=plan_id,
                        description=step_data.get('description', ''),
                        tool=step_data.get('tool', ''),
                        agent=step_data.get('agent', 'code'),
                        **{k: v for k, v in step_data.items()
                           if k not in ['step_id', 'plan_id', 'description', 'tool', 'agent', 'created_at']}
                    )
                except Exception as e:
                    logger.error(f"Failed to create step {original_step_id}: {e}")
                    continue

            # Upsert file index with absolute path
            absolute_path = str(json_file.absolute())
            existing_index = db.get_file_index(plan_id)
            db.upsert_file_index(plan_id, absolute_path)

            action = "updated" if existing_index else "created"
            logger.info(f"File index {action} for plan {plan_id}")

            success_count += 1
            action = "Updated" if existing_plan else "Imported"
            logger.info(f"{action} plan {plan_id} from {json_file.name}")

        except json.JSONDecodeError as e:
            logger.warning(f"Skipping {json_file.name}: Invalid JSON - {e}")
            skip_count += 1
            continue
        except Exception as e:
            error_msg = f"{json_file.name}: {str(e)}"
            logger.error(f"Failed to import plan from {json_file.name}: {e}")
            errors.append(error_msg)
            continue

    logger.info(f"Project scan complete: {success_count} imported, {skip_count} skipped, {len(errors)} errors")
    return success_count, skip_count, errors
