#!/usr/bin/env python3
"""
Plan Format Utilities

Shared utilities for converting between different plan formats, including
screenshot handling for both export format (separated) and standard format (embedded) workflows.
Also includes group reference resolution for merging multiple plan files.
"""

import json
from pathlib import Path
from typing import Any, Dict, List

from vscuse_v2.utils.logger import setup_logger

logger = setup_logger(__name__)


def convert_from_export_format(plan_data: Dict[str, Any]) -> Dict[str, Any]:
    """
    Convert plan data from export format to standard format, embedding screenshot references back into steps.
    This handles the exported format where screenshots are separated into a dedicated section.

    Args:
        plan_data: The raw plan data loaded from exported JSON

    Returns:
        Processed plan data with screenshots embedded back into steps (standard format)
    """
    # Check if this is an exported plan with separated screenshots section
    if 'screenshots' in plan_data and plan_data['screenshots']:
        screenshots = plan_data['screenshots']
        logger.info(f"Converting from export format with {len(screenshots)} screenshots in separate section")

        # Process each step to restore embedded screenshots
        processed_steps = []
        for step in plan_data.get('steps', []):
            step_dict = step.copy()

            # Check if step has a screenshot reference
            screenshot_ref = step_dict.get('screenshot')
            if screenshot_ref and isinstance(screenshot_ref, str) and screenshot_ref in screenshots:
                # Restore the screenshot data URI from the screenshots section
                step_dict['screenshot'] = screenshots[screenshot_ref]
                logger.debug(f"Restored screenshot for step {step_dict.get('step_id', 'unknown')}")

            processed_steps.append(step_dict)

        # Update the plan data with processed steps and remove screenshots section
        processed_plan_data = plan_data.copy()
        processed_plan_data['steps'] = processed_steps
        processed_plan_data.pop('screenshots', None)  # Remove screenshots section

        logger.info(f"Successfully converted {len(processed_steps)} steps from export format to standard format")
        return processed_plan_data

    else:
        # No screenshots section found - plan is already in standard format
        logger.debug("Plan is already in standard format (no separate screenshots section)")
        return plan_data


def convert_to_export_format(plan_metadata: Any, steps: List[Any]) -> Dict[str, Any]:
    """
    Convert plan data from standard format to export format, separating screenshots into a dedicated section.
    This creates the exported format where screenshots are moved out of steps for better readability.

    Args:
        plan_metadata: The plan metadata object (SQLAlchemy model or dict)
        steps: List of step objects from database (SQLAlchemy models or dicts)

    Returns:
        Processed plan data with screenshots separated and consistently ordered (export format)
    """
    from fastapi.encoders import jsonable_encoder

    # Convert SQLAlchemy objects to JSON-serializable dicts (handles datetime, etc.)
    metadata_dict = jsonable_encoder(plan_metadata)
    steps_list = jsonable_encoder(steps)

    # Process screenshots and separate them from steps
    processed_steps = []
    screenshots = {}

    for step in steps_list:
        if step.get('screenshot'):
            # Screenshots are already data URIs from planner phase
            screenshot_data_uri = step['screenshot']

            # Use step_id as the screenshot reference key
            screenshot_key = step['step_id']

            # Store screenshot data separately using step_id as key
            screenshots[screenshot_key] = screenshot_data_uri

            # Replace screenshot data URI with step_id reference for readability
            step['screenshot'] = screenshot_key

        processed_steps.append(step)

    # Sort steps by execution order defined in plan metadata
    execution_order = metadata_dict.get('execution_order', [])
    if execution_order:
        # Create a mapping of step_id to its position in execution order
        order_mapping = {step_id: index for index, step_id in enumerate(execution_order)}

        # Sort steps based on execution order, putting unordered steps at the end
        processed_steps.sort(key=lambda step: order_mapping.get(step.get('step_id'), len(execution_order)))

    logger.info(f"Converted to export format with {len(processed_steps)} steps and {len(screenshots)} screenshots")

    # Build the result structure
    result = {
        "plan_metadata": metadata_dict,
        "steps": processed_steps
    }

    # Only include screenshots section if there are any screenshots
    if screenshots:
        result["screenshots"] = screenshots

    # Normalize property ordering before returning
    return normalize_plan_for_file(result)


def resolve_group_references(plan_data: Dict[str, Any], groups_dir: str) -> Dict[str, Any]:
    """
    Resolve group references in a plan by loading group files and merging them.
    Works with export format (separate screenshots section).

    Args:
        plan_data: Main plan data in export format
        groups_dir: Directory containing group plan files

    Returns:
        Merged plan data in export format with group references resolved

    Raises:
        FileNotFoundError: If groups directory doesn't exist
        ValueError: If no valid group plans are found
    """
    groups_path = Path(groups_dir)
    if not groups_path.exists():
        raise FileNotFoundError(f"Groups directory not found: {groups_dir}")

    logger.info(f"Resolving group references from: {groups_dir}")

    # Load all group files
    all_group_plans = {}
    group_files = list(groups_path.glob('*.json'))

    if not group_files:
        logger.warning(f"No group files found in {groups_dir}")
        return plan_data

    for group_file in group_files:
        try:
            with open(group_file, 'r', encoding='utf-8') as f:
                group_data = json.load(f)

            group_id = group_data.get('plan_metadata', {}).get('plan_id')
            if group_id:
                all_group_plans[group_id] = group_data
                logger.debug(f"Loaded group: {group_data.get('plan_metadata', {}).get('name', 'Unknown')} ({group_id}) from {group_file.name}")
        except Exception as e:
            logger.warning(f"Error loading group file {group_file}: {e}")
            continue

    if not all_group_plans:
        logger.warning("No valid group plans loaded")
        return plan_data

    # Find which groups are actually referenced and expand execution order (recursively)
    execution_order = plan_data.get('plan_metadata', {}).get('execution_order', [])
    referenced_groups = {}

    def expand_order(order: list, visited: set = None) -> list:
        """Recursively expand group references in execution order."""
        if visited is None:
            visited = set()
        expanded = []
        for item in order:
            if item in all_group_plans:
                if item in visited:
                    logger.warning(f"Circular group reference detected: {item}, skipping")
                    continue
                referenced_groups[item] = all_group_plans[item]
                group_order = all_group_plans[item].get('plan_metadata', {}).get('execution_order', [])
                expanded.extend(expand_order(group_order, visited | {item}))
                logger.debug(f"Expanding group reference: {item} -> {len(group_order)} steps")
            else:
                expanded.append(item)
        return expanded

    expanded_order = expand_order(execution_order)

    logger.info(f"Using {len(referenced_groups)} referenced groups")
    logger.info(f"Expanded execution order from {len(execution_order)} to {len(expanded_order)} items")

    # Merge ONLY referenced groups into main plan
    merged_steps = list(plan_data.get('steps', []))
    merged_screenshots = dict(plan_data.get('screenshots', {}))

    for group_data in referenced_groups.values():
        # Add group steps
        group_steps = group_data.get('steps', [])
        merged_steps.extend(group_steps)

        # Merge group screenshots
        group_screenshots = group_data.get('screenshots', {})
        merged_screenshots.update(group_screenshots)

    # Create the merged plan data
    merged_plan = plan_data.copy()
    merged_plan['steps'] = merged_steps
    merged_plan['screenshots'] = merged_screenshots

    # Update execution order in metadata
    if 'plan_metadata' in merged_plan:
        merged_plan['plan_metadata'] = merged_plan['plan_metadata'].copy()
        merged_plan['plan_metadata']['execution_order'] = expanded_order
        merged_plan['plan_metadata']['total_steps'] = len(expanded_order)

    logger.info(f"Total steps: {len(merged_steps)}")
    return merged_plan


def normalize_plan_for_file(plan_data: Dict[str, Any]) -> Dict[str, Any]:
    """
    Normalize plan data to have consistent property ordering before writing to file.
    This ensures minimal diffs when only timestamps change.

    Note: If plan_data contains SQLAlchemy objects, convert them first using
    FastAPI's jsonable_encoder before calling this function.

    Args:
        plan_data: The plan data dict with 'plan_metadata' and 'steps' keys
                   (should already be JSON-serializable)

    Returns:
        Plan data dict with properties in consistent order
    """
    from collections import OrderedDict

    # Define consistent property orders
    METADATA_ORDER = [
        "version", "plan_id", "execution_context", "total_steps",
        "created_at", "name", "description", "generated_at",
        "execution_order", "tags", "updated_at"
    ]

    STEP_ORDER = [
        "step_id", "agent", "tool", "parameters", "description",
        "content_refs", "timeout", "retry_count", "continue_on_error",
        "depends_on", "preconditions", "postconditions",
        "precondition_wait_timeout", "precondition_retry_interval",
        "tags", "screenshot"
    ]

    EXEC_CTX_ORDER = [
        "delay_between_steps", "stop_on_error",
        "precondition_wait_timeout", "precondition_retry_interval"
    ]

    def order_dict(data: Any, key_order: List[str]) -> Any:
        """Recursively order dict keys."""
        if isinstance(data, dict):
            ordered = OrderedDict()
            # Add keys in specified order
            for key in key_order:
                if key in data:
                    value = data[key]
                    if key == "execution_context":
                        ordered[key] = order_dict(value, EXEC_CTX_ORDER)
                    elif isinstance(value, dict):
                        ordered[key] = order_dict(value, [])
                    elif isinstance(value, list):
                        ordered[key] = [order_dict(item, []) for item in value]
                    else:
                        ordered[key] = value

            # Add remaining keys in alphabetical order
            for key in sorted(set(data.keys()) - set(key_order)):
                value = data[key]
                if isinstance(value, dict):
                    ordered[key] = order_dict(value, [])
                elif isinstance(value, list):
                    ordered[key] = [order_dict(item, []) for item in value]
                else:
                    ordered[key] = value

            return ordered

        elif isinstance(data, list):
            return [order_dict(item, key_order) for item in data]

        return data

    # Normalize the structure
    result = OrderedDict()

    if 'plan_metadata' in plan_data:
        result['plan_metadata'] = order_dict(plan_data['plan_metadata'], METADATA_ORDER)

    if 'steps' in plan_data:
        result['steps'] = [order_dict(step, STEP_ORDER) for step in plan_data['steps']]

    if 'screenshots' in plan_data:
        result['screenshots'] = plan_data['screenshots']

    return result
