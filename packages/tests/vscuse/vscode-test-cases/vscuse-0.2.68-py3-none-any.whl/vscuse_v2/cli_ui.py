#!/usr/bin/env python3
"""
VSC-Use UI CLI - A simple web interface for VSCode automation
"""

import atexit
import os
import signal
import sys
from pathlib import Path
from typing import Optional

import typer
import uvicorn

from vscuse_v2 import __version__
from vscuse_v2.config.config_manager import get_config, reset_config
from vscuse_v2.docker.docker_manager import (
    check_docker_running,
    check_vscode_image,
    is_container_running,
    pull_vscode_image,
    start_vscode_container,
    stop_vscode_container,
    wait_for_container_health,
)
from vscuse_v2.utils.logger import set_log_level_globally

# Create a Typer application instance with a descriptive help message
app = typer.Typer(
    help="VSC-Use UI: A web interface for VSC-Use Debug Tool.",
    add_completion=False
)

# Global variable to track the container name for cleanup
_container_name = None

def cleanup_container():
    """Cleanup function to stop Docker container on exit"""
    if _container_name:
        try:
            if is_container_running(_container_name):
                # Only print message if we haven't already cleaned up in the main thread
                print(f"Signal cleanup: Stopping container {_container_name}...")
                stop_vscode_container(_container_name)
        except Exception as e:
            print(f"Warning: Failed to cleanup container: {e}")

def setup_cleanup_handlers(container_name: str):
    """Setup cleanup handlers for graceful shutdown"""
    global _container_name
    _container_name = container_name

    # Register cleanup function to run on normal exit
    atexit.register(cleanup_container)

    # Register signal handlers for graceful shutdown (Unix-like systems)
    if hasattr(signal, 'SIGTERM'):
        signal.signal(signal.SIGTERM, lambda signum, frame: sys.exit(0))
    if hasattr(signal, 'SIGINT'):
        signal.signal(signal.SIGINT, lambda signum, frame: sys.exit(0))

class Config:
    """Configuration wrapper for VSC-Use UI CLI"""

    def __init__(self, config_file: Optional[str] = None):
        # Use our centralized configuration system
        # Use get_config() instead of creating new instance to prevent double loading
        self.config_manager = get_config(config_file)

        # Get configuration sections
        self.docker_config = self.config_manager.get_section("docker")
        self.server_config = self.config_manager.get_section("server")

        # VSCode image is now handled by the config system with environment variable support

    @property
    def ports(self) -> dict:
        """Get ports configuration."""
        return {
            'novnc': self.docker_config.novnc_port,
            'docker_api': self.docker_config.api_port,
            'vscuse_api': self.server_config.api_port,
        }

    @property
    def container_name(self) -> str:
        """Get container name."""
        return self.docker_config.container_name

    @property
    def workspace_dir(self) -> str:
        """Get workspace directory."""
        return self.docker_config.workspace_dir

    @property
    def app_dir(self) -> str:
        """Get app directory."""
        return self.docker_config.app_dir

    @property
    def extensions_dir(self) -> str:
        """Get extensions directory."""
        return self.docker_config.extensions_dir

    @property
    def vscode_image(self) -> str:
        """Get VSCode image name (supports environment variable override)"""
        return self.docker_config.image_name


def get_env_file_path():
    """
    Create a temporary environment file path in the user's home directory.
    Used to pass environment variables to Uvicorn workers.

    Returns:
        str: The full path to the temporary environment file
    """
    app_dir = os.path.join(os.path.expanduser("~"), ".vscuse")
    if not os.path.exists(app_dir):
        os.makedirs(app_dir, exist_ok=True)
    return os.path.join(app_dir, "temp_env_vars.env")


# This decorator makes this function the default action when no subcommand is provided
@app.callback(invoke_without_command=True)
def main(
    ctx: typer.Context,  # Typer context provides information about the command invocation
    project_path: Optional[str] = typer.Option(
        None, "--project-path", help="Path to the project directory containing executable plan JSON files. Plans will be loaded on-demand when selected in the UI."
    ),
    config_file: Optional[str] = typer.Option(
        None, "--config-file", help="Path to the config file."
    ),
    version: bool = typer.Option(
        False, "--version", help="Print the version of VSC-Use UI and exit."
    ),
):
    """
    VSC-Use UI: A web interface for VSC-Use Debug Tool.

    Run `vscuse-ui --project-path /path/to/plans` to start the application.
    """
    # Check if version flag was provided
    if version:
        typer.echo(f"VSC-Use UI version: {__version__}")
        raise typer.Exit()

    # This conditional checks if a subcommand was provided
    # If no subcommand was specified (e.g., just 'vscuse-ui'), run the UI
    if ctx.invoked_subcommand is None:
        # Validate that project_path is provided when running the UI
        if not project_path:
            typer.echo(typer.style("Error: Missing required option '--project-path'", fg=typer.colors.RED, bold=True))
            typer.echo("\nThe --project-path parameter is required to specify your test plans directory.")
            typer.echo("\nUsage:")
            typer.echo("  vscuse-ui --project-path /path/to/plans")
            typer.echo("\nFor more information, run: vscuse-ui --help")
            raise typer.Exit(1)
        # Reset global config to ensure the user-provided config file is used
        # This is necessary because get_logging_config() at module level initializes
        # the global singleton with default paths before we have parsed arguments.
        if config_file:
            reset_config()
            # Initialize global singleton with the user's config file
            get_config(config_file)

        # Set up logging based on config (after config is loaded/reset)
        from vscuse_v2.config.config_manager import get_logging_config
        set_log_level_globally(get_logging_config().level)

        # Load configuration
        config = Config(config_file)

        # Use host from default
        host = "127.0.0.1"  # Always use localhost

        run_ui(
            host=host,
            config=config,
            project_path=project_path,
        )


def run_ui(
    host: str,
    config: Config,
    project_path: str,
):
    """
    Core logic to run the VSC-Use UI web application.
    """
    # Display a green, bold message
    typer.echo(typer.style("Starting VSC-Use UI", fg=typer.colors.GREEN, bold=True))

    # Remove database file before loading plans to ensure fresh data
    typer.echo()
    typer.echo(typer.style("Resetting database...", fg=typer.colors.CYAN), nl=False)
    from vscuse_v2.server.database import DATABASE_PATH
    if DATABASE_PATH.exists():
        DATABASE_PATH.unlink()
    typer.echo(typer.style(" Done", fg=typer.colors.GREEN, bold=True))

    # Load group references (plans with tags) at startup for group selector
    # Other plans remain lazy-loaded for performance
    typer.echo()
    typer.echo(typer.style("Loading group references (tagged plans)...", fg=typer.colors.CYAN))
    typer.echo(f"Project path: {project_path}")

    from vscuse_v2.utils.project_scanner import scan_and_import_plans

    # Scan and import only plans with tags (group references)
    success_count, skip_count, errors = scan_and_import_plans(
        project_path,
        filter_fn=lambda plan_metadata: bool(plan_metadata.get('tags', []))
    )

    typer.echo(typer.style(f"Loaded {success_count} group reference(s)", fg=typer.colors.GREEN))
    if skip_count > 0:
        typer.echo(typer.style(f"  {skip_count} file(s) skipped (no tags)", fg=typer.colors.YELLOW))
    if errors:
        typer.echo(typer.style(f"  {len(errors)} file(s) had errors", fg=typer.colors.YELLOW))
        for error in errors[:3]:  # Show first 3 errors
            typer.echo(typer.style(f"    - {error}", fg=typer.colors.YELLOW))
    typer.echo(typer.style("Other plans will be loaded on-demand when you select them", fg=typer.colors.GREEN))
    typer.echo()

    # Check Azure Service Principal configuration
    azure_sp_config = config.config_manager.get_section("azure_service_principal")
    if azure_sp_config and azure_sp_config.enabled:
        typer.echo(typer.style("Azure Service Principal authentication: ENABLED", fg=typer.colors.CYAN))
        typer.echo(f"  Client ID: {azure_sp_config.client_id[:8]}...")
        typer.echo(f"  Tenant ID: {azure_sp_config.tenant_id[:8]}...")
    else:
        typer.echo(typer.style("Azure Service Principal authentication: DISABLED", fg=typer.colors.YELLOW))

    # === Docker Setup ===
    # Check if Docker is running and prepare required images
    typer.echo(typer.style("Checking if Docker is running...", fg=typer.colors.CYAN), nl=False)

    if not check_docker_running():
        typer.echo(typer.style(" Failed", fg=typer.colors.RED, bold=True))
        typer.echo("Docker is not running. Please start Docker and try again.")
        typer.echo("\nDocker Installation:")
        typer.echo("  - Windows/Mac: https://www.docker.com/products/docker-desktop")
        typer.echo("  - Linux: https://docs.docker.com/engine/install/")
        raise typer.Exit(1)  # Exit with error code 1
    else:
        typer.echo(typer.style(" OK", fg=typer.colors.GREEN, bold=True))

    # Check and pull Docker images if needed
    vscode_image = config.vscode_image
    typer.echo(typer.style(f"Checking Docker VSCode image ({vscode_image})...", fg=typer.colors.CYAN), nl=False)
    if not check_vscode_image(vscode_image):
        typer.echo(typer.style(" Pulling", fg=typer.colors.YELLOW, bold=True))
        typer.echo(f"Pulling Docker image: {vscode_image} (this may take a few minutes)")
        try:
            pull_vscode_image(vscode_image)
            typer.echo(typer.style("Image pulled successfully", fg=typer.colors.GREEN))
        except Exception as e:
            typer.echo(typer.style(f"Failed to pull image: {e}", fg=typer.colors.RED, bold=True))
            raise typer.Exit(1)
    else:
        typer.echo(typer.style(" OK", fg=typer.colors.GREEN, bold=True))

    # Setup workspace
    Path(config.workspace_dir).mkdir(parents=True, exist_ok=True)
    typer.echo(f"Workspace directory: {config.workspace_dir}")

    # Setup cleanup handlers before starting container
    setup_cleanup_handlers(config.container_name)

    # === Docker Container Setup ===
    # Start VSCode container with noVNC
    typer.echo(f"Starting VSCode container ({config.container_name})...", nl=False)

    # Check if container is already running
    if is_container_running(config.container_name):
        typer.echo(typer.style(" Already Running", fg=typer.colors.GREEN, bold=True))
    else:
        # Start the container
        if start_vscode_container(
            vscode_image,
            config.container_name,
            config.workspace_dir,
            config.app_dir,
            config.extensions_dir,
            config.ports
        ):
            typer.echo(typer.style(" Started", fg=typer.colors.GREEN, bold=True))

            # Wait for container to be ready
            typer.echo("Waiting for VSCode container to be ready...", nl=False)
            if wait_for_container_health(config.container_name, timeout=30):
                typer.echo(typer.style(" Ready", fg=typer.colors.GREEN, bold=True))
            else:
                typer.echo(typer.style(" Timeout", fg=typer.colors.YELLOW, bold=True))
                typer.echo("Container started but health check timed out. noVNC may take a moment to be available.")
        else:
            typer.echo(typer.style(" Failed", fg=typer.colors.RED, bold=True))
            typer.echo("Failed to start VSCode container. noVNC will not be available.")
            # Don't exit - continue with just the Web UI

    # Display service URLs
    typer.echo()
    typer.echo(typer.style("VSC-Use Services:", fg=typer.colors.CYAN, bold=True))
    typer.echo(f"  Web UI:          http://{host}:{config.ports['vscuse_api']}")
    typer.echo(f"  noVNC Viewer:    http://{host}:{config.ports['novnc']}")
    typer.echo(f"  Docker API:      http://{host}:{config.ports['docker_api']}")

    typer.echo()
    typer.echo("Press Ctrl+C to stop the server")
    typer.echo()

    typer.echo("Launching VSC-Use UI...")

    # === Environment Setup ===
    # Create environment variables to pass to the web application
    env_vars = {
        "_HOST": host,
        "_NOVNC_PORT": str(config.ports['novnc']),
        "_DOCKER_API_PORT": str(config.ports['docker_api']),
        "_VSCUSE_API_PORT": str(config.ports['vscuse_api']),
        "VERBOSE": "true",  # Enable debug logging
    }

    # Add workspace directory
    env_vars["_WORKSPACE_DIR"] = config.workspace_dir

    # Add project path (required parameter)
    env_vars["_PROJECT_PATH"] = project_path

    # Create a temporary environment file to share with Uvicorn workers
    env_file_path = get_env_file_path()
    with open(env_file_path, "w") as temp_env:
        for key, value in env_vars.items():
            temp_env.write(f"{key}={value}\n")

    # Start the Uvicorn server with the configured settings
    try:
        uvicorn.run(
            "vscuse_v2.server.app:app",  # Path to the ASGI application
            host=host,
            port=config.ports['vscuse_api'],  # Use VSCUse API port, not UI port
            env_file=env_file_path,  # Pass environment variables via file
            log_level="debug",
        )
    except KeyboardInterrupt:
        typer.echo("\nVSC-Use UI server stopped by user")
    except Exception as e:
        typer.echo(typer.style(f"VSC-Use UI server error: {e}", fg=typer.colors.RED))
        raise typer.Exit(1)
    finally:
        # Cleanup section - always runs regardless of how we exit
        typer.echo("\nCleaning up...")

        # Stop the Docker container
        typer.echo(f"Stopping VSCode container ({config.container_name})...", nl=False)
        if stop_vscode_container(config.container_name):
            typer.echo(typer.style(" Stopped", fg=typer.colors.GREEN, bold=True))
        else:
            typer.echo(typer.style(" Failed", fg=typer.colors.YELLOW, bold=True))

        # Clean up temporary environment file
        try:
            if os.path.exists(env_file_path):
                os.remove(env_file_path)
                typer.echo("Temporary files cleaned up")
        except Exception:
            pass  # Ignore cleanup errors

        typer.echo("Cleanup complete")


def run():
    """
    Main entry point called by the 'vscuse-ui' command.
    This function is referenced in pyproject.toml's [project.scripts] section.
    """
    app()


if __name__ == "__main__":
    app()
