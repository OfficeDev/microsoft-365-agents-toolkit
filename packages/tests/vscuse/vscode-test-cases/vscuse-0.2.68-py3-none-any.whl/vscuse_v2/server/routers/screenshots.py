#!/usr/bin/env python3
"""
Screenshots Router

Handles serving screenshot files for the UI.
"""

from pathlib import Path

from fastapi import APIRouter, HTTPException
from fastapi.responses import FileResponse

from vscuse_v2.utils.logger import setup_logger

logger = setup_logger(__name__)
router = APIRouter()


@router.get("")
async def get_screenshot(path: str):
    """Serve screenshot files

    Args:
        path: Absolute file path to the screenshot (passed as query parameter)

    Returns:
        FileResponse: The screenshot image file
    """
    # Convert to Path object
    screenshot_path = Path(path)

    # Security check: ensure file exists and is actually a file
    if not screenshot_path.exists():
        logger.warning(f"Screenshot not found: {path}")
        raise HTTPException(status_code=404, detail=f"Screenshot not found: {path}")

    if not screenshot_path.is_file():
        logger.warning(f"Path is not a file: {path}")
        raise HTTPException(status_code=404, detail=f"Path is not a file: {path}")

    logger.debug(f"Serving screenshot: {screenshot_path.name}")

    # Return the file with appropriate headers
    return FileResponse(
        screenshot_path,
        media_type="image/jpeg",
        headers={
            "Cache-Control": "public, max-age=3600",
            "Access-Control-Allow-Origin": "*"  # Allow CORS for screenshots
        }
    )
