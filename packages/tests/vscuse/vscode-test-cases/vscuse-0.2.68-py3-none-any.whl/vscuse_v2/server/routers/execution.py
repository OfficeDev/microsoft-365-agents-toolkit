#!/usr/bin/env python3
"""
Execution Router

Handles plan execution and individual tool execution requests from the UI.
Acts as an orchestrator between the UI and the underlying execution systems.
"""

import asyncio
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from vscuse_v2.core.executor import Executor
from vscuse_v2.core.resolver import Resolver
from vscuse_v2.core.schema import AgentType, ExecutablePlan, Step, ToolParameters
from vscuse_v2.utils.logger import setup_logger

logger = setup_logger(__name__)
router = APIRouter()

# Simple task tracking for cancellation
_active_plan_tasks: Dict[str, asyncio.Task] = {}
_active_step_tasks: Dict[str, asyncio.Task] = {}


async def execute_single_step_task(step: Step) -> Any:
    """Execute a single step with simple task tracking."""
    current_task = asyncio.current_task()

    # Track this task
    if current_task:
        _active_step_tasks[step.step_id] = current_task

    try:
        async with Executor() as executor:
            return await executor.execute_step(step)
    except asyncio.CancelledError:
        logger.info(f"Step {step.step_id} execution was cancelled")
        raise
    finally:
        # Clean up tracking
        _active_step_tasks.pop(step.step_id, None)


async def execute_plan_task(plan: ExecutablePlan, **kwargs) -> Any:
    """Execute a plan with simple task tracking."""
    plan_id = plan.plan_metadata.plan_id
    current_task = asyncio.current_task()

    # Track this task
    if current_task:
        _active_plan_tasks[plan_id] = current_task

    try:
        async with Executor() as executor:
            return await executor.execute_plan(
                plan,
                start_index=kwargs.get('start_index', 0),
                end_index=kwargs.get('end_index')
            )
    except asyncio.CancelledError:
        logger.info(f"Plan {plan_id} execution was cancelled")
        raise
    finally:
        # Clean up tracking
        _active_plan_tasks.pop(plan_id, None)


# Pydantic models for API requests
class ExecuteStepRequest(BaseModel):
    """Request model for executing a single step."""
    step_id: str
    agent: str = "code"
    tool: str
    parameters: Dict[str, Any] = {}
    description: str = ""
    timeout: Optional[float] = 30.0

    # Dependencies and conditions
    depends_on: Optional[List[str]] = []
    preconditions: Optional[List[str]] = []
    postconditions: Optional[List[str]] = []

    # Natural language support
    tags: Optional[List[str]] = []

    # Screenshot data URI for visual context
    screenshot: Optional[str] = None


class ExecutePlanRequest(BaseModel):
    """Request model for executing a complete plan."""
    plan: Dict[str, Any]  # ExecutablePlan as dict
    start_index: int = 0
    end_index: Optional[int] = None


@router.post("/step/execute")
async def execute_step(request: ExecuteStepRequest):
    """Execute a single step."""
    try:
        logger.info(f"Executing step: {request.step_id} - {request.tool}")

        # Create step object
        step = Step(
            step_id=request.step_id,
            agent=AgentType(request.agent),
            tool=request.tool,
            parameters=ToolParameters(**request.parameters),
            description=request.description,
            timeout=request.timeout,
            depends_on=request.depends_on or [],
            preconditions=request.preconditions or [],
            postconditions=request.postconditions or [],
            tags=request.tags or [],
            screenshot=request.screenshot
        )

        # Execute the step using context manager pattern
        result = await execute_single_step_task(step)

        logger.info(f"Step execution completed: {request.step_id}")
        return {
            "success": True,
            "message": "Step executed successfully",
            "data": result
        }

    except Exception as e:
        logger.error(f"Step execution failed: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Step execution failed: {str(e)}")


@router.post("/plan/{plan_id}/cancel")
async def cancel_plan_execution(plan_id: str):
    """Cancel plan by cancelling its asyncio task directly."""
    try:
        task = _active_plan_tasks.get(plan_id)
        if task and not task.done():
            task.cancel()
            logger.info(f"Cancelled plan task: {plan_id}")
            return {
                "success": True,
                "message": f"Cancelled plan {plan_id}",
                "plan_id": plan_id
            }
        else:
            return {
                "success": False,
                "message": f"Plan {plan_id} not currently running",
                "plan_id": plan_id
            }

    except Exception as e:
        logger.error(f"Failed to cancel plan {plan_id}: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to cancel plan: {str(e)}")


@router.post("/step/{step_id}/cancel")
async def cancel_step_execution(step_id: str):
    """Cancel step by cancelling its asyncio task directly."""
    try:
        task = _active_step_tasks.get(step_id)
        if task and not task.done():
            task.cancel()
            logger.info(f"Cancelled step task: {step_id}")
            return {
                "success": True,
                "message": f"Cancelled step {step_id}",
                "step_id": step_id
            }
        else:
            return {
                "success": False,
                "message": f"Step {step_id} not currently running",
                "step_id": step_id
            }

    except Exception as e:
        logger.error(f"Failed to cancel step {step_id}: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to cancel step: {str(e)}")


@router.post("/cancel-all")
async def cancel_all_executions():
    """Emergency stop - cancel all running tasks."""
    try:
        cancelled_plans = list(_active_plan_tasks.keys())
        cancelled_steps = list(_active_step_tasks.keys())

        # Cancel all plan tasks
        for plan_id, task in _active_plan_tasks.items():
            if not task.done():
                task.cancel()

        # Cancel all step tasks
        for step_id, task in _active_step_tasks.items():
            if not task.done():
                task.cancel()

        logger.info(f"Emergency stop: cancelled {len(cancelled_plans)} plans and {len(cancelled_steps)} steps")
        return {
            "success": True,
            "message": f"Emergency stop: cancelled {len(cancelled_plans)} plans and {len(cancelled_steps)} steps",
            "cancelled_plans": cancelled_plans,
            "cancelled_steps": cancelled_steps
        }

    except Exception as e:
        logger.error(f"Emergency stop failed: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Emergency stop failed: {str(e)}")


@router.post("/reset-runtime-context")
async def reset_runtime_context():
    """Reset the runtime context variables for fresh execution."""
    try:
        # Create a resolver instance and reset its runtime context
        resolver = Resolver()

        # Get current variables for logging (before reset)
        current_vars = resolver.get_runtime_variables()
        vars_count = len(current_vars)

        # Reset the context
        resolver.reset_runtime_variables()

        logger.info(f"Runtime context reset: cleared {vars_count} variables")
        return {
            "success": True,
            "message": f"Runtime context variables reset successfully (cleared {vars_count} variables)",
            "cleared_variables_count": vars_count
        }

    except Exception as e:
        logger.error(f"Failed to reset runtime context: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to reset runtime context: {str(e)}")
