#!/usr/bin/env python3
"""
Project Path API Router

Provides endpoints for retrieving project path configuration and information.
"""

import json
import os
from pathlib import Path
from typing import Optional

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from vscuse_v2.utils.id_generator import generate_plan_id, generate_step_id
from vscuse_v2.utils.logger import setup_logger
from vscuse_v2.utils.plan_format import (
    convert_from_export_format,
    convert_to_export_format,
)

router = APIRouter()
logger = setup_logger(__name__)


class CreatePlanRequest(BaseModel):
    """Request model for creating a new plan file"""
    file_path: str  # File name or path with .json extension (e.g., "my_plan.json" or "folder/my_plan.json")


class DuplicatePlanRequest(BaseModel):
    """Request model for duplicating an existing plan"""
    source_plan_id: str
    new_file_path: str  # File name or path with .json extension (e.g., "my_plan.json" or "folder/my_plan.json")


class RenamePlanRequest(BaseModel):
    """Request model for renaming a plan file"""
    plan_id: str
    new_name: str


class DeletePlanRequest(BaseModel):
    """Request model for deleting a plan file"""
    plan_id: str


class MovePlanRequest(BaseModel):
    """Request model for moving a plan to a new file path"""
    plan_id: str
    new_file_path: str  # New file name or path with .json extension


def get_configured_project_path() -> Optional[Path]:
    """
    Get the configured project path from environment variables.

    Returns:
        Path object if configured, None otherwise
    """
    project_path_str = os.environ.get("_PROJECT_PATH")
    if not project_path_str:
        return None

    return Path(project_path_str).resolve()


def validate_project_path(project_path: Path) -> None:
    """
    Validate that the project path exists and is a directory.

    Args:
        project_path: Path to validate

    Raises:
        HTTPException: If path doesn't exist or is not a directory
    """
    if not project_path.exists():
        raise HTTPException(
            status_code=404,
            detail=f"Project path does not exist: {project_path}"
        )

    if not project_path.is_dir():
        raise HTTPException(
            status_code=400,
            detail=f"Project path is not a directory: {project_path}"
        )


def validate_and_prepare_file_path(project_dir: Path, file_path: str) -> Path:
    """
    Validate and prepare a file path for plan creation/duplication.

    Args:
        project_dir: Project directory path
        file_path: Requested file name or path (with .json extension)

    Returns:
        Resolved file path

    Raises:
        HTTPException: If validation fails
    """
    # Validate that filename ends with .json
    if not file_path.endswith('.json'):
        raise HTTPException(
            status_code=400,
            detail="File name must end with .json extension"
        )

    # Sanitize file path - replace spaces with underscores in all path segments
    sanitized_path = file_path.replace(' ', '_')

    # Validate path doesn't try to escape project directory
    if '..' in sanitized_path or sanitized_path.startswith('/') or sanitized_path.startswith('\\'):
        raise HTTPException(
            status_code=400,
            detail="Invalid file path. Path must be relative and cannot contain '..'."
        )

    # Create full file path
    file_path = project_dir / sanitized_path

    # Ensure the file path is within project directory (security check)
    try:
        file_path_resolved = file_path.resolve()
        project_dir_resolved = project_dir.resolve()
        if not str(file_path_resolved).startswith(str(project_dir_resolved)):
            raise HTTPException(
                status_code=400,
                detail="File path must be within the project directory"
            )
    except Exception as e:
        raise HTTPException(
            status_code=400,
            detail=f"Invalid file path: {str(e)}"
        )

    # Check if file already exists
    if file_path.exists():
        raise HTTPException(
            status_code=409,
            detail=f"A plan file '{sanitized_path}' already exists."
        )

    # Create parent directories if they don't exist
    file_path.parent.mkdir(parents=True, exist_ok=True)

    return file_path


def extract_plan_name_from_filename(file_path: str) -> str:
    """
    Extract plan name from file name by removing path and .json extension.
    Converts underscores back to spaces for display.

    Args:
        file_path: Full file name or path (e.g., "folder/my_plan.json")

    Returns:
        Plan name suitable for display (e.g., "my plan")
    """
    # Extract just the filename (without path)
    plan_name = Path(file_path).name
    # Remove .json extension
    plan_name = plan_name.replace('.json', '')
    # Convert underscores back to spaces for display
    plan_name = plan_name.replace('_', ' ')
    return plan_name


@router.get("/")
async def get_project_path():
    """
    Get the configured project path.

    Returns the project path that was specified when starting vscuse-ui
    with the --project-path parameter.

    Returns:
        dict: Contains status, project_path (or None), and message
    """
    project_path = get_configured_project_path()

    return {
        "status": True,
        "project_path": str(project_path) if project_path else None,
        "message": "Project path retrieved successfully" if project_path else "No project path configured"
    }


@router.get("/scan-files")
async def scan_project_files():
    """
    Scan the project directory for JSON plan files without importing them.

    This endpoint provides a lightweight way to discover available plan files
    for lazy loading. Returns file paths and basic metadata (plan_id, name)
    without loading the full plan into the database.

    Returns:
        dict: Contains status, files list, and message
        files: List of {file_path, plan_id, name, relative_path}
    """
    # Get and validate project path
    project_dir = get_configured_project_path()

    if not project_dir:
        raise HTTPException(
            status_code=400,
            detail="No project path configured. Please start vscuse-ui with --project-path parameter."
        )

    validate_project_path(project_dir)

    logger.info(f"Scanning project directory for plan files: {project_dir}")

    # Find all JSON files recursively
    json_files = list(project_dir.rglob("*.json"))
    logger.info(f"Found {len(json_files)} JSON files")

    files = []

    for json_file in json_files:
        try:
            # Read only the plan_metadata to get plan_id and name (lightweight)
            with open(json_file, 'r', encoding='utf-8') as f:
                data = json.load(f)

            # Check if it's a valid plan file
            if 'plan_metadata' not in data or 'steps' not in data:
                continue

            plan_metadata = data['plan_metadata']
            plan_id = plan_metadata.get('plan_id')

            if not plan_id:
                continue

            # Calculate relative path from project directory
            absolute_path = str(json_file.absolute())
            # Normalize relative path to use forward slashes for consistent frontend handling
            relative_path = str(json_file.relative_to(project_dir)).replace('\\', '/')

            files.append({
                "file_path": absolute_path,
                "plan_id": plan_id,
                "name": plan_metadata.get('name', 'Untitled Plan'),
                "relative_path": relative_path
            })

        except json.JSONDecodeError:
            # Skip invalid JSON files
            continue
        except Exception as e:
            logger.warning(f"Failed to read {json_file.name}: {e}")
            continue

    logger.info(f"Discovered {len(files)} valid plan files")

    return {
        "status": True,
        "files": files,
        "message": f"Found {len(files)} plan files"
    }


@router.post("/create-plan")
async def create_new_plan(request: CreatePlanRequest):
    """
    Create a new plan file in the project directory.

    Args:
        request: CreatePlanRequest with file_path (with .json extension, may include subfolders)

    Returns:
        dict: Contains the created plan data and file_path
    """
    from vscuse_v2.config.config_manager import get_execution_config
    from vscuse_v2.server.database import get_database

    # Get and validate project path
    project_dir = get_configured_project_path()

    if not project_dir:
        raise HTTPException(
            status_code=400,
            detail="No project path configured. Please start vscuse-ui with --project-path parameter."
        )

    validate_project_path(project_dir)

    # Validate and prepare file path
    file_path = validate_and_prepare_file_path(project_dir, request.file_path)

    # Generate new plan ID using the same format as frontend (plan_xxxxxxxx)
    plan_id = generate_plan_id()

    # Get default execution context
    execution_config = get_execution_config()
    default_execution_context = {
        'delay_between_steps': execution_config.delay_between_steps,
        'stop_on_error': execution_config.stop_on_error,
        'precondition_wait_timeout': execution_config.precondition_wait_timeout,
        'precondition_retry_interval': execution_config.precondition_retry_interval,
        'step_retry_timeout': execution_config.step_retry_timeout
    }

    # Extract plan name from filename
    plan_name = extract_plan_name_from_filename(request.file_path)

    # Create plan data - name is just the filename (without folder path)
    plan_data = {
        "plan_metadata": {
            "plan_id": plan_id,
            "name": plan_name,  # Just the filename without path
            "description": "",
            "version": "1.0",
            "execution_context": default_execution_context,
            "execution_order": [],
            "total_steps": 0,
            "tags": []
        },
        "steps": []
    }

    try:
        # Write plan to file with consistent ordering and screenshot handling
        normalized_plan = convert_to_export_format(plan_data['plan_metadata'], plan_data['steps'])
        with open(file_path, 'w', encoding='utf-8') as f:
            json.dump(normalized_plan, f, indent=2, ensure_ascii=False)

        logger.info(f"Created new plan file: {file_path}")

        # Create plan in database
        db = get_database()
        db.create_plan_metadata(
            plan_id=plan_id,
            name=plan_data['plan_metadata']['name'],
            description=plan_data['plan_metadata']['description'],
            version=plan_data['plan_metadata']['version'],
            execution_context=default_execution_context,
            execution_order=[],
            total_steps=0,
            tags=[]
        )

        # Create file index
        db.upsert_file_index(plan_id, str(file_path.absolute()))

        logger.info(f"Created plan {plan_id} in database with file index")

        return {
            "status": True,
            "plan": plan_data,
            "file_path": str(file_path.absolute()),
            "message": f"Plan '{request.file_path}' created successfully"
        }

    except Exception as e:
        logger.error(f"Failed to create plan file: {e}")
        # Clean up file if it was created
        if file_path.exists():
            file_path.unlink()
        raise HTTPException(
            status_code=500,
            detail=f"Failed to create plan: {str(e)}"
        )


@router.post("/duplicate-plan")
async def duplicate_plan(request: DuplicatePlanRequest):
    """
    Duplicate an existing plan to a new file with new IDs.

    Args:
        request: DuplicatePlanRequest with source_plan_id and new_file_path (with .json extension)

    Returns:
        dict: Contains the duplicated plan data and file_path

    Notes:
        - Regular steps get new step IDs
        - Group reference steps (plans with 'group' tag) keep their original IDs
    """
    from vscuse_v2.server.database import get_database

    # Get and validate project path
    project_dir = get_configured_project_path()

    if not project_dir:
        raise HTTPException(
            status_code=400,
            detail="No project path configured. Please start vscuse-ui with --project-path parameter."
        )

    validate_project_path(project_dir)

    # Validate and prepare file path
    new_file_path = validate_and_prepare_file_path(project_dir, request.new_file_path)

    # Get source plan from database
    db = get_database()
    source_plan_metadata = db.get_plan_metadata(request.source_plan_id)

    if not source_plan_metadata:
        raise HTTPException(
            status_code=404,
            detail=f"Source plan '{request.source_plan_id}' not found"
        )

    source_steps = db.get_steps_by_plan_metadata(request.source_plan_id)

    # Generate new plan ID using the same format as frontend (plan_xxxxxxxx)
    new_plan_id = generate_plan_id()

    # Map old IDs to new IDs (for both steps and group references)
    id_map = {}

    # Check if an ID is a group reference (has 'group' tag)
    def is_group_reference(id_to_check: str) -> bool:
        """Check if ID refers to a group reference plan"""
        try:
            group_plan = db.get_plan_metadata(id_to_check)
            if group_plan and 'group' in (group_plan.tags or []):
                return True
        except:
            pass
        return False

    # Process execution order to build ID mapping
    # Group references (plans with 'group' tag) keep their IDs unchanged
    # Regular steps get new IDs
    for item_id in (source_plan_metadata.execution_order or []):
        if is_group_reference(item_id):
            # Keep group reference IDs unchanged (they're not duplicated)
            id_map[item_id] = item_id
            logger.info(f"Preserving group reference ID: {item_id}")
        else:
            # Generate new ID for regular steps
            new_id = generate_step_id()
            id_map[item_id] = new_id
            logger.info(f"Mapping step {item_id} -> {new_id}")

    # Update execution order with new IDs
    new_execution_order = [id_map[item_id] for item_id in (source_plan_metadata.execution_order or [])]

    # Update source plan metadata with new IDs for export
    # Create a temporary metadata object with updated fields
    from copy import deepcopy
    temp_metadata = deepcopy(source_plan_metadata)
    temp_metadata.plan_id = new_plan_id
    temp_metadata.name = extract_plan_name_from_filename(request.new_file_path)
    temp_metadata.execution_order = new_execution_order

    # Update step IDs in steps
    updated_steps = []
    for step in source_steps:
        old_step_id = step.step_id
        new_step_id = id_map.get(old_step_id)

        if not new_step_id:
            logger.warning(f"Step {old_step_id} not found in id_map, skipping")
            continue

        # Create a copy of the step with updated IDs
        from copy import copy
        updated_step = copy(step)
        updated_step.step_id = new_step_id
        updated_step.plan_id = new_plan_id
        updated_steps.append(updated_step)

    try:
        # Use convert_to_export_format to handle SQLAlchemy objects, screenshots, and ordering
        duplicated_plan = convert_to_export_format(temp_metadata, updated_steps)

        # Write duplicated plan to file
        with open(new_file_path, 'w', encoding='utf-8') as f:
            json.dump(duplicated_plan, f, indent=2, ensure_ascii=False)

        logger.info(f"Duplicated plan to new file: {new_file_path}")

        # Create plan in database
        db.create_plan_metadata(
            plan_id=new_plan_id,
            name=duplicated_plan['plan_metadata']['name'],
            description=duplicated_plan['plan_metadata']['description'],
            version=duplicated_plan['plan_metadata']['version'],
            execution_context=duplicated_plan['plan_metadata']['execution_context'],
            execution_order=new_execution_order,
            total_steps=duplicated_plan['plan_metadata']['total_steps'],
            tags=duplicated_plan['plan_metadata']['tags']
        )

        # Convert back from export format to get steps with embedded screenshots for database storage
        # Export format has screenshots separated, but database needs them embedded
        standard_format_plan = convert_from_export_format(duplicated_plan)

        # Create steps in database with embedded screenshot data (not references)
        for step in standard_format_plan['steps']:
            db.create_step(
                step_id=step['step_id'],
                plan_id=new_plan_id,
                description=step.get('description', ''),
                tool=step.get('tool', ''),
                agent=step.get('agent', 'code'),
                **{k: v for k, v in step.items()
                   if k not in ['step_id', 'plan_id', 'description', 'tool', 'agent', 'created_at']}
            )

        # Create file index
        db.upsert_file_index(new_plan_id, str(new_file_path.absolute()))

        logger.info(f"Created duplicated plan {new_plan_id} in database")

        # Return the plan in standard format (already converted above for database)
        return {
            "status": True,
            "plan": standard_format_plan,
            "file_path": str(new_file_path.absolute()),
            "message": f"Plan duplicated successfully as '{request.new_file_path}'"
        }

    except Exception as e:
        logger.error(f"Failed to duplicate plan: {e}")
        # Clean up file if it was created
        if new_file_path.exists():
            new_file_path.unlink()
        raise HTTPException(
            status_code=500,
            detail=f"Failed to duplicate plan: {str(e)}"
        )


@router.post("/rename-plan-file")
async def rename_plan_file(request: RenamePlanRequest):
    """
    Rename a plan's file to match the new plan name.

    Args:
        request: RenamePlanRequest with plan_id and new_name

    Returns:
        dict: Contains status, new file_path, and message
    """
    from vscuse_v2.server.database import get_database

    # Get and validate project path
    project_dir = get_configured_project_path()

    if not project_dir:
        raise HTTPException(
            status_code=400,
            detail="No project path configured. Please start vscuse-ui with --project-path parameter."
        )

    validate_project_path(project_dir)

    # Get current file path from file index
    db = get_database()
    file_index = db.get_file_index(request.plan_id)

    if not file_index:
        raise HTTPException(
            status_code=404,
            detail=f"No file path mapping found for plan {request.plan_id}"
        )

    old_file_path = Path(file_index.file_path)

    if not old_file_path.exists():
        raise HTTPException(
            status_code=404,
            detail=f"Plan file not found: {old_file_path}"
        )

    # Sanitize new name for filename
    sanitized_name = request.new_name.replace(' ', '_')
    sanitized_name = ''.join(c for c in sanitized_name if c.isalnum() or c in ('_', '-'))

    if not sanitized_name:
        raise HTTPException(
            status_code=400,
            detail="Invalid file name. Please use alphanumeric characters, hyphens, or underscores."
        )

    # Create new file path (same directory as old file)
    new_file_path = old_file_path.parent / f"{sanitized_name}.json"

    # Check if target file already exists (and it's not the same file)
    if new_file_path.exists() and new_file_path != old_file_path:
        raise HTTPException(
            status_code=409,
            detail=f"A plan file with name '{sanitized_name}.json' already exists."
        )

    # If the file name hasn't actually changed, no need to rename
    if new_file_path == old_file_path:
        return {
            "status": True,
            "file_path": str(new_file_path.absolute()),
            "message": "File name unchanged"
        }

    try:
        # Read the plan data
        with open(old_file_path, 'r', encoding='utf-8') as f:
            plan_data = json.load(f)

        # Convert from export format first (embeds screenshots back into steps)
        plan_data = convert_from_export_format(plan_data)

        # Update plan name in the data
        plan_data['plan_metadata']['name'] = request.new_name

        # Write to new file with consistent ordering and screenshot handling
        normalized_plan = convert_to_export_format(plan_data['plan_metadata'], plan_data.get('steps', []))
        with open(new_file_path, 'w', encoding='utf-8') as f:
            json.dump(normalized_plan, f, indent=2, ensure_ascii=False)

        # Delete old file
        old_file_path.unlink()

        # Update file index
        db.upsert_file_index(request.plan_id, str(new_file_path.absolute()))

        logger.info(f"Renamed plan file from {old_file_path.name} to {new_file_path.name}")

        return {
            "status": True,
            "file_path": str(new_file_path.absolute()),
            "message": f"Plan file renamed to '{sanitized_name}.json'"
        }

    except Exception as e:
        logger.error(f"Failed to rename plan file: {e}")
        # If new file was created but old file still exists, clean up new file
        if new_file_path.exists() and old_file_path.exists():
            new_file_path.unlink()
        raise HTTPException(
            status_code=500,
            detail=f"Failed to rename plan file: {str(e)}"
        )


@router.post("/move-plan-file")
async def move_plan_file(request: MovePlanRequest):
    """
    Move a plan file to a new location/name.

    Args:
        request: MovePlanRequest with plan_id and new_file_path

    Returns:
        dict: Contains status, new file_path, and message
    """
    from vscuse_v2.server.database import get_database

    # Get and validate project path
    project_dir = get_configured_project_path()

    if not project_dir:
        raise HTTPException(
            status_code=400,
            detail="No project path configured. Please start vscuse-ui with --project-path parameter."
        )

    validate_project_path(project_dir)

    # Get current file path from file index
    db = get_database()
    file_index = db.get_file_index(request.plan_id)

    if not file_index:
        raise HTTPException(
            status_code=404,
            detail=f"No file path mapping found for plan {request.plan_id}"
        )

    old_file_path = Path(file_index.file_path)

    if not old_file_path.exists():
        raise HTTPException(
            status_code=404,
            detail=f"Plan file not found: {old_file_path}"
        )

    # Validate and prepare new file path
    new_file_path = validate_and_prepare_file_path(project_dir, request.new_file_path)

    # If the file path hasn't actually changed, no need to move
    if new_file_path == old_file_path:
        return {
            "status": True,
            "file_path": str(new_file_path.absolute()),
            "message": "File path unchanged"
        }

    try:
        # Read the plan data
        with open(old_file_path, 'r', encoding='utf-8') as f:
            plan_data = json.load(f)

        # Convert from export format first (embeds screenshots back into steps)
        plan_data = convert_from_export_format(plan_data)

        # Update plan name to match new filename (optional, keeps consistency)
        new_plan_name = extract_plan_name_from_filename(request.new_file_path)
        plan_data['plan_metadata']['name'] = new_plan_name

        # Write to new location with consistent ordering and screenshot handling
        normalized_plan = convert_to_export_format(plan_data['plan_metadata'], plan_data.get('steps', []))
        with open(new_file_path, 'w', encoding='utf-8') as f:
            json.dump(normalized_plan, f, indent=2, ensure_ascii=False)

        # Delete old file
        old_file_path.unlink()

        # Update file index
        db.upsert_file_index(request.plan_id, str(new_file_path.absolute()))

        # Update plan name in database
        db.update_plan_metadata(
            plan_id=request.plan_id,
            name=new_plan_name
        )

        logger.info(f"Moved plan file from {old_file_path} to {new_file_path}")

        return {
            "status": True,
            "file_path": str(new_file_path.absolute()),
            "message": f"Plan moved to '{request.new_file_path}'"
        }

    except Exception as e:
        logger.error(f"Failed to move plan file: {e}")
        # If new file was created but old file still exists, clean up new file
        if new_file_path.exists() and old_file_path.exists():
            new_file_path.unlink()
        raise HTTPException(
            status_code=500,
            detail=f"Failed to move plan file: {str(e)}"
        )


@router.post("/delete-plan-file")
async def delete_plan_file(request: DeletePlanRequest):
    """
    Delete a plan file permanently.

    Args:
        request: DeletePlanRequest with plan_id

    Returns:
        dict: Contains status and message
    """
    from vscuse_v2.server.database import get_database

    # Get and validate project path
    project_dir = get_configured_project_path()

    if not project_dir:
        raise HTTPException(
            status_code=400,
            detail="No project path configured. Please start vscuse-ui with --project-path parameter."
        )

    validate_project_path(project_dir)

    # Get current file path from file index
    db = get_database()
    file_index = db.get_file_index(request.plan_id)

    if not file_index:
        raise HTTPException(
            status_code=404,
            detail=f"No file path mapping found for plan {request.plan_id}"
        )

    file_path = Path(file_index.file_path)

    if not file_path.exists():
        raise HTTPException(
            status_code=404,
            detail=f"Plan file not found: {file_path}"
        )

    try:
        # Get plan name for message
        plan_metadata = db.get_plan_metadata(request.plan_id)
        plan_name = plan_metadata.name if plan_metadata else "Unknown"

        # Delete the file
        file_path.unlink()
        logger.info(f"Deleted plan file: {file_path}")

        # Delete from database (plan and all its steps)
        from vscuse_v2.server.database import PlanMetadata, Step
        with db.get_session() as session:
            # Delete all steps associated with this plan
            session.query(Step).filter(Step.plan_id == request.plan_id).delete()

            # Delete the plan itself
            session.query(PlanMetadata).filter(PlanMetadata.plan_id == request.plan_id).delete()

            session.commit()

        logger.info(f"Deleted plan metadata and steps for {request.plan_id}")

        # Delete file index
        db.delete_file_index(request.plan_id)
        logger.info(f"Deleted file index for {request.plan_id}")

        return {
            "status": True,
            "message": f"Plan '{plan_name}' deleted successfully"
        }

    except Exception as e:
        logger.error(f"Failed to delete plan file: {e}")
        raise HTTPException(
            status_code=500,
            detail=f"Failed to delete plan: {str(e)}"
        )
