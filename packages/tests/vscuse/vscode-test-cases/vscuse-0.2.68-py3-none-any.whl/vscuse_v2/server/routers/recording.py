"""Recording API endpoints for test plan generation."""

import json
import uuid
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field

from vscuse_v2.config.config_manager import get_docker_config
from vscuse_v2.core.planner import Planner
from vscuse_v2.core.schema import ExecutablePlan
from vscuse_v2.docker.docker_client import DockerClient, DockerServiceError
from vscuse_v2.server.database import create_recording, get_database, get_recording, list_recordings, update_recording
from vscuse_v2.server.routers.project_path import get_configured_project_path
from vscuse_v2.utils.logger import setup_logger
from vscuse_v2.utils.plan_format import normalize_plan_for_file

logger = setup_logger(__name__)
router = APIRouter(tags=["recording"])

# Global cache for generated plans (in production, use Redis)
_plan_cache = {}
CACHE_TTL_MINUTES = 30


class StopRecordingResponse(BaseModel):
    """Response model for stopping recording."""
    recording_id: str
    total_interactions: int
    duration_seconds: float


class StepResponse(BaseModel):
    """
    Step response model with only database-compatible fields.

    Note: This data model somehow needs to align with the Step schema eventually.
    The Step schema in core/schema.py contains additional fields like content_refs,
    retry_count, continue_on_error, etc. that are not supported by the database Step model.
    This StepResponse model only includes fields that can be safely stored and retrieved
    from the database to avoid "invalid keyword argument" errors during step insertion.

    TODO: Consider unifying the Step schema and database model in the future to eliminate
    this duplication and maintain better consistency across the system.
    """
    step_id: str
    agent: str  # Already converted to string value from enum
    tool: str
    parameters: Dict[str, Any] = Field(default_factory=dict)
    description: str
    tags: List[str] = Field(default_factory=list)
    postconditions: List[str] = Field(default_factory=list)
    preconditions: List[str] = Field(default_factory=list)
    depends_on: List[str] = Field(default_factory=list)
    timeout: float = 30.0
    screenshot: Optional[str] = Field(None, description="Screenshot path for step execution")


# Remove GeneratePlanResponse - we'll use ExecutablePlan directly from schema.py


async def get_or_generate_plan(recording_id: str) -> ExecutablePlan:
    """Get cached plan or generate new one to avoid duplicate LLM calls."""
    cache_key = f"plan_{recording_id}"

    # Check cache
    if cache_key in _plan_cache:
        cached_data = _plan_cache[cache_key]
        if datetime.now() - cached_data['timestamp'] < timedelta(minutes=CACHE_TTL_MINUTES):
            logger.info(f"Using cached plan for recording {recording_id}")
            return cached_data['plan']
        else:
            # Remove expired cache
            del _plan_cache[cache_key]
            logger.info(f"Cache expired for recording {recording_id}")

    # Generate new plan
    logger.info(f"Generating new plan for recording {recording_id}")
    recording = get_recording(recording_id)

    if not recording:
        raise HTTPException(status_code=404, detail="Recording not found")

    if recording.status != "stopped":
        raise HTTPException(status_code=400, detail="Recording must be stopped before generating plan")

    if not recording.output_file:
        raise HTTPException(status_code=400, detail="Recording has no output file")

    # Get the actual recording path from the database (same logic as generate_executable_plan)
    docker_config = get_docker_config()
    clean_output_file = recording.output_file.removeprefix('/app/data').lstrip('/')
    base_dir = Path(docker_config.app_dir)
    recording_path = base_dir / clean_output_file

    if not recording_path.exists():
        raise HTTPException(
            status_code=404,
            detail=f"Recording file not found. Looked for: {recording_path.absolute()}"
        )

    # Generate plan using Planner
    planner = Planner(recording_path)
    executable_plan = await planner.generate_plan()

    # Cache the result
    _plan_cache[cache_key] = {
        'plan': executable_plan,
        'timestamp': datetime.now()
    }

    logger.info(f"Generated and cached plan for recording {recording_id}")
    return executable_plan


@router.post("/start", response_model=Dict[str, str])
async def start_recording():
    """Start recording computer interactions."""
    try:
        # Initialize Docker client
        docker_client = DockerClient()

        # Check if Docker service is available
        if not docker_client.is_service_available():
            raise HTTPException(
                status_code=503,
                detail="Docker service is not available. Please ensure the Docker container is running."
            )

        # Start recording in Docker
        docker_response = docker_client.start_recording()

        recording_id = docker_response.get("recording_id", f"rec_{uuid.uuid4().hex[:8]}")

        # Create recording in database
        create_recording(
            recording_id=recording_id,
            status="recording",
            start_time=datetime.now()
        )

        logger.info(f"Started recording: {recording_id}")

        return {
            "recording_id": recording_id,
            "status": "success",
            "message": "Recording started successfully"
        }

    except DockerServiceError as e:
        logger.error(f"Docker service error: {e}")
        raise HTTPException(status_code=503, detail=f"Docker service error: {e}")
    except Exception as e:
        logger.error(f"Error starting recording: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to start recording: {e}")


@router.post("/stop/{recording_id}", response_model=StopRecordingResponse)
async def stop_recording(recording_id: str):
    """Stop recording and return the recorded actions."""
    # Get recording from database
    recording = get_recording(recording_id)

    if not recording:
        raise HTTPException(status_code=404, detail="Recording not found")

    if recording.status != "recording":
        raise HTTPException(status_code=400, detail="Recording is not active")

    try:
        # Stop recording in Docker
        docker_client = DockerClient()
        docker_response = docker_client.stop_recording()

        # Calculate duration
        end_time = datetime.now()
        duration_seconds = 0.0
        if recording.start_time:
            duration_seconds = (end_time - recording.start_time).total_seconds()

        # Get recorded actions from Docker response
        docker_interactions = docker_response.get("total_interactions", 0)

        # Update recording in database
        update_recording(
            recording_id=recording_id,
            status="stopped",
            end_time=end_time,
            duration=int(duration_seconds),
            total_interactions=docker_interactions,
            output_file=docker_response.get("output_file"),
            screenshot_dir=docker_response.get("screenshot_dir")
        )

        logger.info(f"Stopped recording: {recording_id}, Duration: {duration_seconds:.2f}s, Interactions: {docker_interactions}")

        response = StopRecordingResponse(
            recording_id=recording_id,
            total_interactions=docker_interactions,
            duration_seconds=duration_seconds
        )

        return response

    except Exception as e:
        logger.error(f"Error stopping recording: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to stop recording: {e}")


@router.get("/status/{recording_id}")
async def get_recording_status(recording_id: str):
    """Get status of a recording."""
    recording = get_recording(recording_id)

    if not recording:
        raise HTTPException(status_code=404, detail="Recording not found")

    duration_seconds = 0.0
    if recording.start_time:
        end_time = recording.end_time or datetime.now()
        duration_seconds = (end_time - recording.start_time).total_seconds()

    return {
        "recording_id": recording_id,
        "status": recording.status,
        "duration_seconds": duration_seconds,
        "start_time": recording.start_time.isoformat() if recording.start_time else None,
        "end_time": recording.end_time.isoformat() if recording.end_time else None,
        "total_interactions": recording.total_interactions,
        "output_file": recording.output_file,
        "screenshot_dir": recording.screenshot_dir
    }


@router.get("/list")
async def list_recordings_endpoint():
    """List all recordings."""
    recordings = list_recordings(limit=100)  # Get latest 100 recordings

    recordings_data = []
    for recording in recordings:
        duration_seconds = 0.0
        if recording.start_time:
            end_time = recording.end_time or datetime.now()
            duration_seconds = (end_time - recording.start_time).total_seconds()

        recordings_data.append({
            "recording_id": recording.recording_id,
            "status": recording.status,
            "duration_seconds": duration_seconds,
            "start_time": recording.start_time.isoformat() if recording.start_time else None,
            "end_time": recording.end_time.isoformat() if recording.end_time else None,
            "total_interactions": recording.total_interactions,
            "output_file": recording.output_file,
            "screenshot_dir": recording.screenshot_dir
        })

    # Get database statistics
    db = get_database()
    stats = db.get_recording_stats()

    return {
        "status": "success",
        "recordings": recordings_data,
        "statistics": stats
    }


@router.post("/{recording_id}/executable_plan", response_model=ExecutablePlan)
async def generate_executable_plan(recording_id: str):
    """Generate an executable plan from a completed recording."""
    try:
        # Get recording from database
        recording = get_recording(recording_id)

        if not recording:
            raise HTTPException(status_code=404, detail="Recording not found")

        if recording.status != "stopped":
            raise HTTPException(status_code=400, detail="Recording must be stopped before generating a plan")

        if not recording.output_file:
            raise HTTPException(status_code=400, detail="Recording has no output file")

        # Get the actual recording path from the database
        # Use docker app_dir configuration and clean the output_file path
        docker_config = get_docker_config()

        # Remove /app/data prefix from output_file if present
        clean_output_file = recording.output_file.removeprefix('/app/data').lstrip('/')

        # Use docker app_dir + cleaned output_file path
        base_dir = Path(docker_config.app_dir)
        recording_path = base_dir / clean_output_file

        if not recording_path.exists():
            raise HTTPException(
                status_code=404,
                detail=f"Recording file not found. Looked for: {recording_path.absolute()}"
            )

        logger.info(f"Generating plan for recording {recording_id} from file: {recording_path.absolute()}")

        # Use cached plan if available, otherwise generate new one
        executable_plan = await get_or_generate_plan(recording_id)

        # Extract data for response
        plan_id = executable_plan.plan_metadata.plan_id

        # Store plan in database using the planner's metadata (no duplication)
        logger.info(f"Storing new plan {plan_id} in database")
        db = get_database()
        db.create_plan_metadata(
            plan_id=plan_id,
            name=executable_plan.plan_metadata.name,
            description=executable_plan.plan_metadata.description.model_dump() if executable_plan.plan_metadata.description else None,
            total_steps=len(executable_plan.steps),
            tags=executable_plan.plan_metadata.tags,
            execution_context=executable_plan.plan_metadata.execution_context.model_dump() if executable_plan.plan_metadata.execution_context else None,
            execution_order=executable_plan.plan_metadata.execution_order  # Store execution order
        )

        # Store steps in database with enhanced schema
        for step in executable_plan.steps:
            db.create_step(
                step_id=step.step_id,
                plan_id=plan_id,
                description=step.description,
                tool=step.tool,
                agent=step.agent.value,
                parameters=step.parameters.model_dump(exclude_none=True) if step.parameters else {},
                tags=step.tags or [],
                postconditions=step.postconditions or [],
                preconditions=step.preconditions or [],
                depends_on=step.depends_on or [],
                timeout=step.timeout or 30,
                screenshot=step.screenshot
            )

        logger.info(f"Generated plan {plan_id} with {len(executable_plan.steps)} steps")

        # Create a file in the project directory if project path is configured
        project_path = get_configured_project_path()
        if project_path and project_path.exists() and project_path.is_dir():
            try:
                # Sanitize plan name for filename (replace spaces with underscores)
                safe_name = executable_plan.plan_metadata.name.replace(' ', '_')
                safe_name = ''.join(c for c in safe_name if c.isalnum() or c in ('_', '-'))

                if not safe_name:
                    safe_name = f"recording_{recording_id}"

                # Create file path
                file_path = project_path / f"{safe_name}.json"

                # If file exists, add a suffix
                counter = 1
                while file_path.exists():
                    file_path = project_path / f"{safe_name}_{counter}.json"
                    counter += 1

                # Prepare plan data for file
                plan_data = {
                    "plan_metadata": {
                        "plan_id": executable_plan.plan_metadata.plan_id,
                        "name": executable_plan.plan_metadata.name,
                        "description": (
                            executable_plan.plan_metadata.description.model_dump()
                            if executable_plan.plan_metadata.description
                            else None
                        ),
                        "version": executable_plan.plan_metadata.version or "1.0",
                        "execution_context": (
                            executable_plan.plan_metadata.execution_context.model_dump()
                            if executable_plan.plan_metadata.execution_context
                            else {}
                        ),
                        "execution_order": executable_plan.plan_metadata.execution_order or [],
                        "total_steps": len(executable_plan.steps),
                        "tags": executable_plan.plan_metadata.tags or []
                    },
                    "steps": [
                        {
                            "step_id": step.step_id,
                            "agent": step.agent.value if hasattr(step.agent, 'value') else str(step.agent),
                            "tool": step.tool,
                            "parameters": step.parameters.model_dump(exclude_none=True) if step.parameters else {},
                            "description": step.description,
                            "tags": step.tags or [],
                            "postconditions": step.postconditions or [],
                            "preconditions": step.preconditions or [],
                            "depends_on": step.depends_on or [],
                            "timeout": step.timeout or 30,
                            "screenshot": step.screenshot
                        }
                        for step in executable_plan.steps
                    ]
                }

                # Write plan to file with consistent ordering
                normalized_plan = normalize_plan_for_file(plan_data)
                with open(file_path, 'w', encoding='utf-8') as f:
                    json.dump(normalized_plan, f, indent=2, ensure_ascii=False)

                # Create file index entry
                db.upsert_file_index(plan_id, str(file_path.absolute()))

                logger.info(f"Created plan file: {file_path.absolute()}")
            except Exception as file_error:
                logger.error(f"Failed to create plan file (non-fatal): {file_error}")
                # Don't fail the entire request if file creation fails
        else:
            logger.info("No project path configured or path invalid - plan file not created")

        # Return the complete ExecutablePlan directly from planner (no metadata override)
        return executable_plan

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error generating plan for recording {recording_id}: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to generate test plan: {e}")


@router.post("/{recording_id}/extract_steps", response_model=List[StepResponse])
async def extract_steps_from_recording(recording_id: str):
    """Extract steps from a recording without creating a plan or storing in database."""
    try:
        # Get recording from database
        recording = get_recording(recording_id)

        if not recording:
            raise HTTPException(status_code=404, detail="Recording not found")

        if recording.status != "stopped":
            raise HTTPException(status_code=400, detail="Recording must be stopped before extracting steps")

        if not recording.output_file:
            raise HTTPException(status_code=400, detail="Recording has no output file")

        # Get the actual recording path from the database
        docker_config = get_docker_config()
        clean_output_file = recording.output_file.removeprefix('/app/data').lstrip('/')
        base_dir = Path(docker_config.app_dir)
        recording_path = base_dir / clean_output_file

        if not recording_path.exists():
            raise HTTPException(
                status_code=404,
                detail=f"Recording file not found. Looked for: {recording_path.absolute()}"
            )

        logger.info(f"Extracting steps from recording {recording_id} from file: {recording_path.absolute()}")

        # Use cached plan if available, otherwise generate new one
        executable_plan = await get_or_generate_plan(recording_id)

        logger.info(f"Extracted {len(executable_plan.steps)} steps from recording {recording_id}")

        # Convert Step objects to StepResponse objects with only database-compatible fields
        response_steps = []
        for step in executable_plan.steps:
            response_step = StepResponse(
                step_id=step.step_id,
                agent=step.agent.value if hasattr(step.agent, 'value') else str(step.agent),
                tool=step.tool,
                parameters=step.parameters.model_dump(exclude_none=True) if step.parameters else {},
                description=step.description,
                tags=step.tags or [],
                postconditions=step.postconditions or [],
                preconditions=step.preconditions or [],
                depends_on=step.depends_on or [],
                timeout=step.timeout or 30,
                screenshot=step.screenshot
            )
            response_steps.append(response_step)

        logger.info(f"Returning {len(response_steps)} database-compatible step responses")
        return response_steps

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error extracting steps from recording {recording_id}: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to extract steps: {e}")
